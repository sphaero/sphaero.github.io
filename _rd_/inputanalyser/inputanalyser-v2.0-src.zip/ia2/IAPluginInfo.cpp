/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org

    This file is part of Virtools Input Analyser.

    Input Analyser is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    Input Analyser is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Input Analyser; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef IA_GETFREQ_BB_GUID
#define IA_GETFREQ_BB_GUID	CKGUID( 0x1e454fa3,0x3a215ebf )
#endif
#ifndef IA_GETVOL_BB_GUID
#define IA_GETVOL_BB_GUID	CKGUID( 0x673c4029,0x1d406e62 )
#endif
#ifndef IA_GETMAXFREQ_BB_GUID
#define IA_GETMAXFREQ_BB_GUID	CKGUID( 0xc3d550e,0xcdb6d2b )
#endif

#include "CKAll.h"
#include "InputAnalyser.h"

//Virtools Plugin info

// Manager INIT
CKERROR InitInputAnalyserMan(CKContext *ctx)
{
	new InputAnalyserMan(ctx);
	return CK_OK;
}

// Manager EXIT
CKERROR ExitInputAnalyserMan(CKContext *ctx)
{
	InputAnalyserMan *man=(InputAnalyserMan*)ctx->GetManagerByName(MyManagerName);
	delete man;
	return CK_OK;
}

CKPluginInfo g_PluginInfo[4];

int CKGetPluginInfoCount() { return 4; }

CKPluginInfo *CKGetPluginInfo(int Index)
{
			g_PluginInfo[0].m_Author			= "KnP";
			g_PluginInfo[0].m_Description		= "Records sound input and performs analysis";
			g_PluginInfo[0].m_Extension			= "";
			g_PluginInfo[0].m_Type				= CKPLUGIN_MANAGER_DLL;
			g_PluginInfo[0].m_Version			= 0x000002;
			g_PluginInfo[0].m_InitInstanceFct	= InitInputAnalyserMan;
			g_PluginInfo[0].m_ExitInstanceFct	= ExitInputAnalyserMan;
			g_PluginInfo[0].m_GUID				= INPUT_ANALYSER_GUID;
			g_PluginInfo[0].m_Summary			= MyManagerName;

			g_PluginInfo[1].m_Author			= "KnP";
			g_PluginInfo[1].m_Description		= "Gets frequency data from InputAnalyser manager";
			g_PluginInfo[1].m_Extension		= "";
			g_PluginInfo[1].m_Type				= CKPLUGIN_BEHAVIOR_DLL;
			g_PluginInfo[1].m_Version			= 0x000002;
			g_PluginInfo[1].m_InitInstanceFct	= NULL; //
			g_PluginInfo[1].m_GUID				= IA_GETFREQ_BB_GUID;
			g_PluginInfo[1].m_Summary			= "BB gets data from InputAnalyser manager which captures from sound input";

			g_PluginInfo[1].m_Author			= "KnP";
			g_PluginInfo[1].m_Description		= "Gets volume from InputAnalyser manager";
			g_PluginInfo[1].m_Extension		= "";
			g_PluginInfo[1].m_Type				= CKPLUGIN_BEHAVIOR_DLL;
			g_PluginInfo[1].m_Version			= 0x000002;
			g_PluginInfo[1].m_InitInstanceFct	= NULL; //
			g_PluginInfo[1].m_GUID				= IA_GETVOL_BB_GUID;
			g_PluginInfo[1].m_Summary			= "BB gets data from InputAnalyser manager which captures from sound input";
			
			g_PluginInfo[1].m_Author			= "KnP";
			g_PluginInfo[1].m_Description		= "Gets most found freq from InputAnalyser manager data";
			g_PluginInfo[1].m_Extension		= "";
			g_PluginInfo[1].m_Type				= CKPLUGIN_BEHAVIOR_DLL;
			g_PluginInfo[1].m_Version			= 0x000002;
			g_PluginInfo[1].m_InitInstanceFct	= NULL; //
			g_PluginInfo[1].m_GUID				= IA_GETMAXFREQ_BB_GUID;
			g_PluginInfo[1].m_Summary			= "BB gets data from InputAnalyser manager which captures from sound input";

			return &g_PluginInfo[Index];
}

CKObjectDeclaration	*FillBehaviorIAGetFreqBBDecl();
CKObjectDeclaration *FillBehaviorIAGetVolBBDecl();
CKObjectDeclaration *FillBehaviorIAGetMaxFreqBBDecl();
// Additionnal behaviors definitions should be added here....

//	This function should be present and exported for Virtools
//	to be able to retrieve objects declarations.
//	Virtools will call this function at initialization
void RegisterBehaviorDeclarations(XObjectDeclarationArray *reg)
{
	reg->PushBack(FillBehaviorIAGetFreqBBDecl());
	reg->PushBack(FillBehaviorIAGetVolBBDecl());
	reg->PushBack(FillBehaviorIAGetMaxFreqBBDecl());
// Additionnal behaviors registrations should be added here....
}

