/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org

    This file is part of Virtools Input Analyser.

    Input Analyser is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    Input Analyser is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Input Analyser; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Declarations of the Behavior Building Block
#ifndef IA_GETVOL_BB_GUID
#define IA_GETVOL_BB_GUID	CKGUID( 0x673c4029,0x1d406e62 )
#endif
#include "CKAll.h"
#include "InputAnalyser.h"

CKObjectDeclaration	*FillBehaviorIAGetVolBBDecl();
CKERROR CreateIAGetVolBBProto(CKBehaviorPrototype **);
int IAGetVolBB(const CKBehaviorContext& BehContext);

CKObjectDeclaration	*FillBehaviorIAGetVolBBDecl()
{
	CKObjectDeclaration *od = CreateCKObjectDeclaration("IAGetVolBB");	
	
	od->SetType(CKDLL_BEHAVIORPROTOTYPE);
	od->SetVersion(0x000002);
	od->SetCreationFunction(CreateIAGetVolBBProto);
	od->SetDescription("Get volume information from IA manager");
	od->SetCategory("Sounds/InputAnalyser");
	od->SetGuid(IA_GETVOL_BB_GUID);
	od->SetAuthorGuid(CKGUID(0x56495254,0x4f4f4c53));
	od->SetAuthorName("KnP");
	od->SetCompatibleClassId(CKCID_BEOBJECT);

	return od;
}

CKERROR CreateIAGetVolBBProto(CKBehaviorPrototype** pproto)
{
	CKBehaviorPrototype *proto = CreateCKBehaviorPrototype("IAGetVolBB");
	if(!proto) 	return CKERR_OUTOFMEMORY;

//---	Inputs declaration
	proto->DeclareInput("In0");
							
//---	Outputs declaration
	proto->DeclareOutput("Out0");
				
//---	Output Parameters Declaration
	proto->DeclareOutParameter("volume L",CKPGUID_INT);
	proto->DeclareOutParameter("volume R",CKPGUID_INT);

//----	Local Parameters Declaration

//----	Settings Declaration
	proto->SetFlags(CK_BEHAVIORPROTOTYPE_NORMAL);
//	proto->SetBehaviorFlags((CK_BEHAVIOR_FLAGS)(CKBEHAVIOR_VARIABLEPARAMETERINPUTS|CKBEHAVIOR_INTERNALLYCREATEDOUTPUTPARAMS));
	proto->SetFunction(IAGetVolBB);

	*pproto = proto;
	return CK_OK;
}

int IAGetVolBB(const CKBehaviorContext& BehContext)
{
	CKBehavior *beh = BehContext.Behavior;

	beh->ActivateInput(0, FALSE);
	beh->ActivateOutput(0);
	
	InputAnalyserMan *man = (InputAnalyserMan*)BehContext.Context->GetManagerByGuid( INPUT_ANALYSER_GUID );
	if (!man){
			BehContext.Context->OutputToConsoleEx("Can't get the InputAnalyser Manager");
			return CKBR_GENERICERROR;
	}
	
	//output volume;
	int vol=(int)man->gem[0];
	beh->SetOutputParameterValue(0, &vol);
	vol=(int)man->gem[1];
	beh->SetOutputParameterValue(1, &vol);

	return CKBR_OK;
}
