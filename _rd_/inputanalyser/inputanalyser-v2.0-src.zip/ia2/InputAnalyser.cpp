/////////////////
// InputAnalyzer v2.0 - sphaero.org/KnP
//
// released under the GNU Lesser General Public License (www.gnu.org)
// We ask people when using this library to report this to dev@sphaero.org or wreck@k-n-p.org
// though this is not obliged, just kindly requested.
// People who make additions to this library are also asked to report this so others
// can benefit.
/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org

    This file is part of Virtools Input Analyser.

    Input Analyser is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    Input Analyser is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Input Analyser; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#define INPUT_ANALYSER_BB_GUID	CKGUID( 0x1e454fa3,0x3a215ebf )
#include "CKAll.h"
#include "InputAnalyser.h"

// Frame Count class function definitions
//constructor
InputAnalyserMan::InputAnalyserMan(CKContext *ctx):CKBaseManager(ctx,INPUT_ANALYSER_GUID, MyManagerName)
{
	// Register the manager
	ctx->RegisterNewManager(this);
	
	gem[0]=100;
	gem[1]=100;
	snd=0;
	max[0]=0;
	max[1]=0;
	maxi[0]=0;
	maxi[1]=0;
}

//destructor
CKERROR InputAnalyserMan::OnCKEnd()
{
	sndin_free(snd);
	return CK_OK;
}

//Manager INIT will be run on Virtools Startup
CKERROR InputAnalyserMan::OnCKInit()
{
	snd=sndin_init(44100,2,16,640*1024);
	if(snd==0)
	{
		sndin_free(snd);
		return CKBR_GENERICERROR;
	}
	fft.Init(BUFSIZE,FFTSIZE);
	return CK_OK;
}

//Reset will be run when Virtools will be reseted (aka rewinded)
CKERROR InputAnalyserMan::OnCKReset()
{
	return CK_OK;
}

//Will be run before the frame is executed and rendered and forms the main execution loop
CKERROR InputAnalyserMan::PreProcess()
{
	if (snd!=0)
	{
		sndin_capture(snd,(void*)sambuffer,BUFSIZE*4);
	}
	float *sambf0=sambf[0];
	float *sambf1=sambf[1];
	short *sambuf=sambuffer;
	for (int i=0;i<BUFSIZE;i++)
	{
		*sambf0=*sambuf++; 
		gem[0]+=fabs(*sambf0++); 
		*sambf1=*sambuf++; 
		gem[1]+=fabs(*sambf1++); 
	}

	fft.time_to_frequency_domain(sambf[0],fftbufs[0]);
	fft.time_to_frequency_domain(sambf[1],fftbufs[1]);
	gem[0]=gem[0]/BUFSIZE;
	gem[1]=gem[1]/BUFSIZE;

	return CK_OK;
}



//Function to retrieve the average frequency value of the frequency range
float InputAnalyserMan::GetRangeAvg(float *array,int start,int end)
{
  int i;
  int len;
  float f=0;
  float *a;

  if(start>end) return 0;
  if(start==end) return array[start];

  a=&array[start];
  len=end-start;

  for(i=0;i<=len;i++)
    f+=*(a++);

  return (f/(float)len);
}

// function to get the highest value of the frequency range
float InputAnalyserMan::GetRangeMax(float *array,int start,int end)
{
  int i;
  int len;
  float f=0;
  float *a;

  if(start>end) return 0;
  if(start==end) return array[start];

  a=&array[start];
  len=end-start;

  for(i=0;i<=len;i++)
  {
    if(*a>f) f=*a;
    a++;
  }

  return f;
}

// function to convert the frequency into an array number
int InputAnalyserMan::FreqToIndex(int freq,int rate,int fftsize)
{
  int i=0;
  int maxfreq=rate/2;

  if(freq==0) return 0;

  i=(int) ((((float)freq/(float)maxfreq)*(float)fftsize));

  if(i>maxfreq) return fftsize-1;
  if(freq<0) return 0;
  return i;
}

//Gets the current most active frequency
void InputAnalyserMan::GetMaxFreq(void)
{
	max[0]/=2;
	max[1]/=2;
	for (int i=0;i<FFTSIZE;i++)
	{
		if(fftbufs[0][i]>max[0]) 
		{
			max[0]=fftbufs[0][i];maxi[0]=i;
		}
		if(fftbufs[1][i]>max[1]) 
		{
			max[1]=fftbufs[1][i];maxi[1]=i;
		}
	}
}

// END Class functie defenities


