/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org

    This file is part of Virtools Input Analyser.

    Input Analyser is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    Input Analyser is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Input Analyser; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

//InputAnanlyser Class Defenition
#ifndef MyManagerName
#define MyManagerName "SoundInputAnalyser"
#endif
#define INPUT_ANALYSER_GUID CKGUID(0xe685921,0x616c6d7e)
#define BUFSIZE 512
#define FFTSIZE (BUFSIZE/2)
#define VERSION 0x00000002
#include "sound.h"
#include "fft.h"


class InputAnalyserMan : public CKBaseManager 
{
public:
	InputAnalyserMan(CKContext *ctx);
	~InputAnalyserMan() {}

	// User Functions
	float GetGem(int c)		 { return gem[c]; }
	short GetSamBuffer(int c,int i) { return sambuffer[i];  }
	float *GetFftBuffer(int c) { return fftbufs[c];    }
    float GetRangeAvg(float *array,int start,int end);
    float GetRangeMax(float *array,int start,int end);
    int FreqToIndex(int freq,int rate,int fftsize);
	void GetMaxFreq();

	// Virtual overrides
	CKERROR OnCKReset();
	CKERROR PreProcess();
	CKERROR OnCKInit();
	CKERROR OnCKEnd();

	// Valid functions mask
	CKDWORD	GetValidFunctionsMask()	{ return CKMANAGER_FUNC_OnCKReset|
											 CKMANAGER_FUNC_PreProcess|
											 CKMANAGER_FUNC_OnCKInit|
											 CKMANAGER_FUNC_OnCKEnd;}

	//Class vars..
	short sambuffer[BUFSIZE*2];
	float sambf[2][BUFSIZE];
	
	float gem[2];
	float max[2]; 
	int maxi[2];

	float fftbufs[2][FFTSIZE];

	//float sound_low,sound_mid,sound_high;

	SNDIN *snd;
	FFT fft;

};
