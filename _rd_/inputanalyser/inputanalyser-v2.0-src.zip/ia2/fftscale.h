void fftscale(float *in,float *out,int size) 
{
	int i;
	int o;
	float y;
	float scale,x00,y00;
	float height=512;
	float d=0.33;
	float tau=3;
	float dif=4;


	scale = height / ( log((1 - d) / d) * 2 );
	x00 = d*d*32768.0/(2 * d - 1);
	y00 = -log(-x00) * scale;


	/* FIXME: can anything taken out of the main thread? */
	for (i = 0; i < size; i++) {
    o=size-i;
		y = in[o] * (i + 1); /* Compensating the energy */
		y = ( log(y - x00) * scale + y00 ); /* Logarithmic amplitude */

		y = ( (dif-2)*y + /* FIXME: conditionals should be rolled out of the loop */
			(o==0       ? y : in[o-1]) +
			(o==256-1 ? y : in[o+1])) / dif; /* Add some diffusion */
		y = ((tau-1)*out[o] + y) / tau; /* Add some dynamics */
		out[o] = y;
	}
	return;
}
