/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org

    This file is part of Virtools Input Analyser.

    Input Analyser is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    Input Analyser is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Input Analyser; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "sound.h"

/*
  sndin v1.0 by Ronald Hof (wreck@k-n-p.org)

    Quick hack to get the most recent samples from the default recording device.
    Not very usefull for anything other than analyzing the sound input.

    uses directsound
*/


/*
  sndin_init
    initialialize and start sound capturing

  inputs:
      int freq       : capture frequency (in samples per second)
      int chan       : number of channels, 1 for mono, 2 for stereo
      int bits       : bits per sample, 8 or 16.
      int buffersize : size of the internal capture buffer (in bytes)
                       (must be a lot larger than the amount of samples you want
                       captured by sndin_capture)
      
  outputs:
      SNDIN*    : pointer to initialized SNDIN structure,
                  or 0 if failed.                
*/

SNDIN *sndin_init(int freq,int chan,int bits,int buffersize)
{
  HRESULT hr;
  SNDIN *snd;
  int b=bits/8;
  
  snd=(SNDIN*)malloc(sizeof(SNDIN));

  snd->pDSBCapture=0;
  snd->pDSCapture=0;

  hr=DirectSoundCaptureCreate8(&DSDEVID_DefaultCapture,&snd->pDSCapture,0);
  if(hr!=DS_OK) {sndin_free(snd);return 0;}
  ZeroMemory( &snd->dscbd, sizeof(snd->dscbd) );
  ZeroMemory( &snd->wfx,sizeof(snd->wfx));

  snd->wfx.wFormatTag=WAVE_FORMAT_PCM;
  snd->wfx.nChannels=chan;
  snd->wfx.nSamplesPerSec=freq;
  snd->wfx.nAvgBytesPerSec=freq*chan*b;
  snd->wfx.nBlockAlign=chan*b;
  snd->wfx.wBitsPerSample=bits;
  snd->wfx.cbSize=0;


  snd->dscbd.dwSize=sizeof(snd->dscbd);
  snd->dscbd.dwBufferBytes=buffersize;
  snd->dscbd.lpwfxFormat=&snd->wfx;
  snd->buffersize=buffersize;
  
  hr=snd->pDSCapture->CreateCaptureBuffer(&snd->dscbd, &snd->pDSBCapture,NULL);
  if(hr!=DS_OK) {sndin_free(snd);return 0;}
  
  hr=snd->pDSBCapture->Start(DSCBSTART_LOOPING);
  if(hr!=DS_OK) {sndin_free(snd);return 0;}

  return snd;
}


/*
  sndin_capture
    grab the most recent recorded samples.

  inputs:
    SNDIN *snd   :  pointer to SNDIN structure returned by sndin_init
    void *buffer :  pointer to buffer to put sample data in
    int size     :  amount of data to capture (in bytes,NOT samples!)
                    (must be a lot smaller than the size parameter of
                    sndin_init.)

  outputs:
    int          :  0 if capture failed

*/
int sndin_capture(SNDIN *snd,void *buffer,int size)
{
  HRESULT hr;
  unsigned long pos,len1,len2;
  char *buf1,*buf2;
  void *cbuf1,*cbuf2;
  char *buf;
  unsigned int i;
  
  buf=(char *)buffer;
  if(snd->pDSBCapture==0) return 0;
  snd->pDSBCapture->GetCurrentPosition(&pos,0);
  pos-=size+1024*2;
  if(pos<0) pos+=snd->buffersize;
  hr=snd->pDSBCapture->Lock(pos,size,&cbuf1,&len1,&cbuf2,&len2,0);
  if(hr==DS_OK)
  {
    buf1=(char *)cbuf1;
    buf2=(char *)cbuf2;
    for(i=0;i<len1;i++)
      *buf++=*buf1++;
    if(len2!=0)
      for(i=0;i<len2;i++)
        *buf++=*buf2++;
    snd->pDSBCapture->Unlock(cbuf1,len1,cbuf2,len2);
    return 1;
  }
  else
    return 0;
}

/*
   sndin_free
     stop recording and clean up.

  inputs:
    SNDIN *snd   : pointer to SNDIN structure returned by sndin_init

  outputs:
    none
*/
void sndin_free(SNDIN *snd)
{
  if(snd==0) return;
  if(snd->pDSBCapture!=0) snd->pDSBCapture->Stop();

  SAFE_RELEASE(snd->pDSBCapture);
  SAFE_RELEASE(snd->pDSCapture);
  free(snd);
}

