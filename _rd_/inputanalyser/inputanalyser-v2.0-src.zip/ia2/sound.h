/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org

    This file is part of Virtools Input Analyser.

    Input Analyser is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    Input Analyser is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Input Analyser; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
  sndin v1.0 by Ronald Hof (wrecK/KnP)

    Quick hack to get the N most recent samples from the default recording device.
    Not very usefull for anything other than analyzing the sound input.

    uses directsound
*/

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#include "dsound.h"

#pragma comment( lib, "dsound.lib" )
#pragma comment( lib, "dxguid.lib" )


struct SNDIN
{
  LPDIRECTSOUNDCAPTURE   pDSCapture;
  LPDIRECTSOUNDCAPTUREBUFFER pDSBCapture;
  LPDIRECTSOUNDNOTIFY        pDSNotify;
  DSCBUFFERDESC      dscbd;
  WAVEFORMATEX     wfx;
  int buffersize;
};

SNDIN *sndin_init(int freq,int chan,int bits,int buffersize);
int sndin_capture(SNDIN *snd,void *buffer,int size);
void sndin_free(SNDIN *snd);

