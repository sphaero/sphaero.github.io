/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org/Stichting Lange Poten

	This plugin has been created for a research about historical 
	stereophotographics and stereographics for use in theatrical performances. 
	This research (Het Archief) was initiated by Stichting Lange Poten. 
	(http://www.lange-poten.nl)

    This file is part of Virtools NetSync Manager Building Block.

    NetSync Manager is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    NetSync Manager is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with NetSync Manager; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#ifndef VNETWORK_GUID
#define VNETWORK_GUID	CKGUID( 0x3bdd4a7c,0x5b083c70 )
#endif
#ifndef VNSLAVE_BB_GUID
#define VNSLAVE_BB_GUID	CKGUID( 0x11dc02fc,0x3eb05b34 )
#endif
#ifndef VNMASTER_BB_GUID
#define VNMASTER_BB_GUID	CKGUID( 0x2ec63163,0x17e36f58 )
#endif
#ifndef MyManagerName
#define MyManagerName "VirtoolsNetworkManager"
#endif

#include "CKAll.h"
#include "VNetSync.h"

//constructor
VNetworkMan::VNetworkMan(CKContext *ctx):CKBaseManager(ctx,VNETWORK_GUID, MyManagerName)
{
	// Register the manager
	ctx->RegisterNewManager(this);

	//initialise variables
	sprintf(host, "127.0.0.1");
	port=6868;
	timeout=10;
	slave=false;
	slv_on=false;
	mst_on=false;
	socket_on=false;

	//set status code
	out[0]=0;
	status=4; //Virtools sents reset on first play... this bypasses it
	framecount=0;

	//This will tell windows to access the WinSock subsystem
	//and sets the version to use
	WSADATA wsa_data;
    WSAStartup(MAKEWORD(1,1), &wsa_data);
}

//destructor
CKERROR VNetworkMan::OnCKEnd()
{
	//We no longer need to access the WinSock subsystem
	if (slave)
	{
		VN_slave_stop();
	}
	else
	{
		VN_master_stop();
	}
    WSACleanup();
	return CK_OK;
}

//Manager INIT will be run on Virtools Startup
CKERROR VNetworkMan::OnCKInit()
{
	slv_on=0;
	mst_on=0;
	return CK_OK;
}

CKERROR VNetworkMan::OnCKPlay()
{
	if (socket_on)
	{
		if (slave)
		{
			VN_slave_start();
		}
		else
		{
			VN_master_start();
			out[0]=2;
		}
	}
	return CK_OK;
}

CKERROR VNetworkMan::OnCKPause()
{
	if (slave)
	{
		if (slv_on) VN_slave_stop();
	}
	else
	{
		if (mst_on) 
		{
			out[0]=3;
			sock_master_senddata(&out,mst);
			VN_master_stop();
		}
	}
	return CK_OK;
}

//Reset will be run when Virtools will be reseted (aka rewinded or IC)
CKERROR VNetworkMan::OnCKReset()
{
	if (slave)
	{
		if (slv_on) VN_slave_stop();
	}
	else
	{
		if (mst_on) 
		{
			out[0]=4;
			sock_master_senddata(&out,mst);
			VN_master_stop();
		}
	}
	return CK_OK;
}

//Will be run before the frame is executed and rendered and forms the main execution loop
CKERROR VNetworkMan::PreProcess()
{
	if (slave)
	{
		if (slv_on)
		{
			in=(float *)sock_slave_getdata(slv,timeout);
			framecount++;
			VN_enslaving();
		}
	}
	else
	{
		if (mst_on) 
		{
			sock_master_senddata(&out,mst);
			framecount++;
		}
	}
	return CK_OK;
}

// Start master
int VNetworkMan::VN_master_start()
{
	if (mst_on) VN_master_stop();
	m_Context->OutputToConsole("VNetwork: Opening master socket");
	mst=sock_master_start(sizeof(float[20]),host,port);
	if(mst==0)
	{
		m_Context->OutputToConsole("Opening master socket failed... Did you run the slave prior to running the master?");
		return 1;
	}
	else 
	{
		mst_on=1;
		out[0]=1;
	}
	return 0;
}

//Stop Master
void VNetworkMan::VN_master_stop()
{
	m_Context->OutputToConsole("VNetwork: Closing master socket");
	m_Context->OutputToConsoleEx("VNetwork: counted %d frames", framecount);
	sock_master_stop(mst);
	mst_on=0;
	out[0]=0;
	framecount=0;
}

//Start slave
int VNetworkMan::VN_slave_start()
{
	if (slv_on) VN_slave_stop();
	m_Context->OutputToConsole("VNetwork: Waiting for master...");
	slv=sock_slave_start(port,timeout);
	if(slv==0)
	{
		m_Context->OutputToConsole("Opening slave socket failed");
		return 1;
	}
	else
	{
		m_Context->OutputToConsole("VNetwork: Master found");
		slv_on=1;
		in[0]=4;
	}
	return 0;
}

//stop slave
void VNetworkMan::VN_slave_stop()
{
	m_Context->OutputToConsole("VNetwork: Closing slave socket");
	m_Context->OutputToConsoleEx("VNetwork: counted %d frames", framecount);
	sock_slave_stop(slv);
	slv_on=0;
	in[0]=1;
}

//Enslaving function checks the status which is received from master [0]
void VNetworkMan::VN_enslaving()
{
	if (!(status==(int)(in[0])))
	{
		status=(int)(in[0]);
		switch (status) 
		{
		case 0: 
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Socket Dead", in[0]);
			break;
		case 1:
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Socket Alive", in[0]);
			break;
		case 2:
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Master sends Play", in[0]);
			break;
		case 3:
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Master sends Pause", in[0]);
			m_Context->Pause();
			//m_Context->Process();
			break;
		case 4:
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Master sends Reset", in[0]);
			m_Context->Reset();
			//m_Context->Process();
			break;
		default:
		    m_Context->OutputToConsoleEx("VNetworkSlave: %d = This should not be printed. Illegal status code", in[0]);
			break;
		}
	}
	else status=(int)(in[0]);
}

// Some control functions
void VNetworkMan::VN_SocketStart(bool set_on)
{
	socket_on = set_on;
}

bool VNetworkMan::VN_IsSocketSetOn()
{
	return socket_on;
}

bool VNetworkMan::VN_IsSlave()
{
	return slave;
}

void VNetworkMan::VN_SetModus(bool set_modus)
{
	slave = set_modus;
}

void VNetworkMan::VN_SetHostname(char set_hostname[256])
{
	sprintf(host, set_hostname);
}

void VNetworkMan::VN_SetPort(int set_portnumber)
{
	port = set_portnumber;
}

void VNetworkMan::VN_SetTimeOut(int set_timeout)
{
	timeout = set_timeout;
}

