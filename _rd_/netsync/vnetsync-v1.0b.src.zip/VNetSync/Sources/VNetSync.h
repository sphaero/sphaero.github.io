//Network Manager Class Defenition
#ifndef VNETWORK_GUID
#define VNETWORK_GUID	CKGUID( 0x3bdd4a7c,0x5b083c70 )
#endif
#ifndef VNSLAVE_BB_GUID
#define VNSLAVE_BB_GUID	CKGUID( 0x11dc02fc,0x3eb05b34 )
#endif
#ifndef VNMASTER_BB_GUID
#define VNMASTER_BB_GUID	CKGUID( 0x2ec63163,0x17e36f58 )
#endif
#ifndef MyManagerName
#define MyManagerName "VirtoolsNetworkManager"
#endif

#include "sock.h"

class VNetworkMan : public CKBaseManager 
{
public:
	VNetworkMan(CKContext *ctx);
	~VNetworkMan() {}

	// User Functions
	int VN_master_start();
	void VN_master_stop();
	int VN_slave_start();
	void VN_slave_stop();
	void VN_enslaving();

	void VN_SocketStart(bool set_on);
	bool VN_IsSocketSetOn();
	bool VN_IsSlave();
	void VN_SetModus(bool set_modus);
	void VN_SetHostname(char set_hostname[256]);
	void VN_SetPort(int set_portnumber);
	void VN_SetTimeOut(int set_timeout);
	//void VN_FillOut(float filldata[16]);


	// Virtual overrides
	CKERROR OnCKReset();
	CKERROR PreProcess();
	CKERROR OnCKInit();
	CKERROR OnCKPlay();
	CKERROR OnCKPause();
	CKERROR OnCKEnd();

	// Valid functions mask
	CKDWORD	GetValidFunctionsMask()	{ return CKMANAGER_FUNC_OnCKReset|
											 CKMANAGER_FUNC_PreProcess|
											 CKMANAGER_FUNC_OnCKInit|
											 CKMANAGER_FUNC_OnCKPlay|
											 CKMANAGER_FUNC_OnCKPause|
											 CKMANAGER_FUNC_OnCKEnd;}

	//Class vars..
	// Booleans to control manager
	bool socket_on; //do we want the socket to be started? 
	bool slave;   //is the manager running as master or slave?
	bool mst_on;  //is master on?
	bool slv_on;  //is slave on?

	//char to hold hostname/ipaddr for master to connect to.
	char host[256];
	//int to hold the portnumber.
	int port;
	//int to hold timeout value (s)
	int timeout;

	//master en slave structs
	sock_master_struct *mst;
	sock_slave_struct *slv;

	//the first float [0] contains status codes:
	// 0 = connection dead
	// 1 = connection alive
	// 2 = play
	// 3 = pause
	// 4 = reset (which should be followed by 1)
	float out[20];
	float *in;
	int status;

	//counts frames in order to give sync feedback
	int framecount;
	

};
