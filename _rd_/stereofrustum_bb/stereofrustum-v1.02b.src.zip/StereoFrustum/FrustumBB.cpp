/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org/Stichting Lange Poten

	This plugin has been created for a research about historical 
	stereophotographics and stereographics for use in theatrical performances. 
	This research (Het Archief) was initiated by Stichting Lange Poten. 
	(http://www.lange-poten.nl)

    This file is part of StereoFrustum Building Block.

    StereoFrustum is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    StereoFrustum is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with StereoFrustum; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	#############################
	# CHANGELOG
	#############################

	# v1.02b 16-01-04
	- fix incorrect eyedistance usuage

	# v1.01b 13-01-04
	- fix incorrect correction after editing BB

*/

#ifndef FRUSTUM_BB_GUID
#define FRUSTUM_BB_GUID CKGUID( 0xc57124a,0x6f1646b0 )
#endif

#include "CKAll.h"

//Virtools Plugin info

CKPluginInfo g_PluginInfo;

int CKGetPluginInfoCount() { return 1; }

CKPluginInfo *CKGetPluginInfo(int Index)
{
			g_PluginInfo.m_Author			= "KnP";
			g_PluginInfo.m_Description		= "Modifies the view frustum for 1 eye for off-axis stereo projection";
			g_PluginInfo.m_Extension		= "";
			g_PluginInfo.m_Type				= CKPLUGIN_BEHAVIOR_DLL;
			g_PluginInfo.m_Version			= 0x00010000;
			g_PluginInfo.m_InitInstanceFct	= NULL; //
			g_PluginInfo.m_GUID				= FRUSTUM_BB_GUID;
			g_PluginInfo.m_Summary			= "Stereographics Frustum correction";

			return &g_PluginInfo;
}

CKObjectDeclaration	*FillBehaviorFrustumBBDecl();
// Additionnal behaviors definitions should be added here....

//	This function should be present and exported for Virtools
//	to be able to retrieve objects declarations.
//	Virtools will call this function at initialization
void RegisterBehaviorDeclarations(XObjectDeclarationArray *reg)
{
	reg->PushBack(FillBehaviorFrustumBBDecl());
// Additionnal behaviors registrations should be added here....
}


// Declarations of the Behavior Building Block

#ifndef FRUSTUM_BB_GUID
#define FRUSTUM_BB_GUID CKGUID( 0xc57124a,0x6f1646b0 )
#endif

#define DTOR 0.0174532925

CKObjectDeclaration	*FillBehaviorFrustumBBDecl();
CKERROR CreateFrustumBBProto(CKBehaviorPrototype **);
int FrustumBB(const CKBehaviorContext& BehContext);

CKERROR FrustumBBCallBack(const CKBehaviorContext& BehContext);

CKObjectDeclaration	*FillBehaviorFrustumBBDecl()
{
	CKObjectDeclaration *od = CreateCKObjectDeclaration("FrustumBB");	
	
	od->SetType(CKDLL_BEHAVIORPROTOTYPE);
	od->SetVersion(0x00010000);
	od->SetCreationFunction(CreateFrustumBBProto);
	od->SetDescription("Stereographics Frustum correction");
	od->SetCategory("Cameras/FX");
	od->SetGuid(FRUSTUM_BB_GUID);
	od->SetAuthorGuid(CKGUID(0x56495254,0x4f4f4c53));
	od->SetAuthorName("KnP");
	od->SetCompatibleClassId(CKCID_CAMERA);

	return od;
}

CKERROR CreateFrustumBBProto(CKBehaviorPrototype** pproto)
{
	CKBehaviorPrototype *proto = CreateCKBehaviorPrototype("FrustumBB");
	if(!proto) 	return CKERR_OUTOFMEMORY;

//---	Inputs declaration
	proto->DeclareInput("In0");
							
//---	Outputs declaration
	proto->DeclareOutput("Out0");
							
//----- Input Parameters Declaration
	proto->DeclareInParameter("LeftEyePosition?",CKPGUID_BOOL);
	proto->DeclareInParameter("Eye-distance(0=auto)",CKPGUID_FLOAT, "0");
	proto->DeclareInParameter("Focal",CKPGUID_FLOAT, "50");
							
//---	Output Parameters Declaration
	proto->DeclareOutParameter("ProjectionMatrix",CKPGUID_MATRIX);
	proto->DeclareOutParameter("Eyedistance(from center)", CKPGUID_FLOAT);

//----	Local Parameters Declaration

//----	Settings Declaration
	proto->SetFlags(CK_BEHAVIORPROTOTYPE_NORMAL);
	proto->SetBehaviorFlags((CK_BEHAVIOR_FLAGS)(CKBEHAVIOR_INTERNALLYCREATEDOUTPUTPARAMS));
	proto->SetFunction(FrustumBB);

//----  Callback Decl.
	proto->SetBehaviorCallbackFct( FrustumBBCallBack);

	*pproto = proto;
	return CK_OK;
}

float CorrectionExpCalc(float camera_focallength, float camera_fov, float eyedistance, float camera_nearclip, float camera_ratio)
{
	float left, right, wd2, ndfl;

	wd2   =   camera_nearclip * tan(camera_fov / 2);
	ndfl  =   camera_nearclip / camera_focallength;
	left  = - camera_ratio * wd2 - eyedistance * ndfl;
	right =   camera_ratio * wd2 - eyedistance * ndfl;
	
	return (right + left) / (right - left);
}

void SetNewProjectionMatrix(CKRenderContext *RenderContext, void *argument)
{
	CKBehavior *beh = (CKBehavior*)argument;

	CKCamera *Camera = (CKCamera *) beh->GetTarget();

	//Declare vars
	VxMatrix mat;					//for the transformation matrix
	int		width, height;			//for aspect ratio calculation
	float	fov, EyeDistance, CameraNear, CameraFocal, CameraRatio, CorrectionExp;
	bool	b_left;					//to set which eye (left or right)

	//Assign vars
	mat	=	RenderContext->GetProjectionTransformationMatrix();
	fov	=	Camera->GetFov();
	beh->GetInputParameterValue(1, &EyeDistance);
	CameraNear	=	Camera->GetFrontPlane();
	beh->GetInputParameterValue(2, &CameraFocal);
				// If no Eyedistance value is set this formula will calculate a workable value
	if (EyeDistance==0) EyeDistance = CameraFocal/40;
	
	Camera->GetAspectRatio(width, height);
	CameraRatio	=	width / (float)height;
	CorrectionExp=CorrectionExpCalc(CameraFocal, fov, EyeDistance, CameraNear, CameraRatio);
	beh->GetInputParameterValue(0, &b_left);

	//Some functioning
	//Context->OutputToConsoleEx("VNetwork: fov %f, EyeDistance %f, CameraNear %f, CameraFocal %f, CameraRatio %f, CorrectionExp %f", fov, EyeDistance, CameraNear, CameraFocal, CameraRatio, CorrectionExp);
	if (!b_left) CorrectionExp*=-1;
	mat[2][0]=CorrectionExp;
	beh->SetOutputParameterValue(0, &mat);
	RenderContext->SetProjectionTransformationMatrix(mat);
}

int FrustumBB(const CKBehaviorContext& BehContext)
{
	CKBehavior *beh = BehContext.Behavior;
	//CKContext *Context = BehContext.Context;
	CKRenderContext *RenderContext = BehContext.CurrentRenderContext;

	//Init BB
	beh->ActivateInput(0, FALSE);
	beh->ActivateOutput(0);	

	bool b_left;
	float EyeDistance;
	beh->GetInputParameterValue(0, &b_left);
	beh->GetInputParameterValue(1, &EyeDistance);

	if (EyeDistance==0) 
	{
		float CameraFocal;
		beh->GetInputParameterValue(2, &CameraFocal);
		EyeDistance=CameraFocal/40;
	}
	
	if (b_left) EyeDistance*=-1;
	beh->SetOutputParameterValue(1, &EyeDistance);

	//Set PreRender Callback Function
	RenderContext->AddPreRenderCallBack(SetNewProjectionMatrix,(void*)beh, TRUE);

	return CKBR_OK;
}

//********************************
// CALLBACK
//********************************

CKERROR FrustumBBCallBack(const CKBehaviorContext& BehContext){
  
	CKBehavior* beh = BehContext.Behavior;
	
	CKRenderContext *RenderContext = BehContext.CurrentRenderContext;

	switch( BehContext.CallbackMessage )
	{
		case CKM_BEHAVIORSETTINGSEDITED:
		case CKM_BEHAVIOREDITED:
		{
			bool b_left;
			float EyeDistance;
			beh->GetInputParameterValue(0, &b_left);
			beh->GetInputParameterValue(1, &EyeDistance);
	
			if (EyeDistance==0) 
			{
				float CameraFocal;
				beh->GetInputParameterValue(2, &CameraFocal);
				EyeDistance=CameraFocal/40;
			}
			if (!b_left) EyeDistance*=-1;
			beh->SetOutputParameterValue(1, &EyeDistance);

			//Set PreRender Callback Function
			RenderContext->AddPreRenderCallBack(SetNewProjectionMatrix,(void*)beh, TRUE);
			break;
		}
		default:
			break;
	}
	return CKBR_OK; 
}