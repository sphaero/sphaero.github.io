// Declarations of the Behavior Building Block
#ifndef IA_GETVOL_BB_GUID
#define IA_GETVOL_BB_GUID	CKGUID( 0x673c4029,0x1d406e62 )
#endif
#include "CKAll.h"
#include "InputAnalyser.h"

CKObjectDeclaration	*FillBehaviorIAGetVolBBDecl();
CKERROR CreateIAGetVolBBProto(CKBehaviorPrototype **);
int IAGetVolBB(const CKBehaviorContext& BehContext);

CKObjectDeclaration	*FillBehaviorIAGetVolBBDecl()
{
	CKObjectDeclaration *od = CreateCKObjectDeclaration("IAGetVolBB");	
	
	od->SetType(CKDLL_BEHAVIORPROTOTYPE);
	od->SetVersion(0x00010000);
	od->SetCreationFunction(CreateIAGetVolBBProto);
	od->SetDescription("Get volume information from IA manager");
	od->SetCategory("Sounds/InputAnalyser");
	od->SetGuid(IA_GETVOL_BB_GUID);
	od->SetAuthorGuid(CKGUID(0x56495254,0x4f4f4c53));
	od->SetAuthorName("KnP");
	od->SetCompatibleClassId(CKCID_BEOBJECT);

	return od;
}

CKERROR CreateIAGetVolBBProto(CKBehaviorPrototype** pproto)
{
	CKBehaviorPrototype *proto = CreateCKBehaviorPrototype("IAGetVolBB");
	if(!proto) 	return CKERR_OUTOFMEMORY;

//---	Inputs declaration
	proto->DeclareInput("In0");
							
//---	Outputs declaration
	proto->DeclareOutput("Out0");
				
//---	Output Parameters Declaration
	proto->DeclareOutParameter("volume",CKPGUID_INT);

//----	Local Parameters Declaration

//----	Settings Declaration
	proto->SetFlags(CK_BEHAVIORPROTOTYPE_NORMAL);
//	proto->SetBehaviorFlags((CK_BEHAVIOR_FLAGS)(CKBEHAVIOR_VARIABLEPARAMETERINPUTS|CKBEHAVIOR_INTERNALLYCREATEDOUTPUTPARAMS));
	proto->SetFunction(IAGetVolBB);

	*pproto = proto;
	return CK_OK;
}

int IAGetVolBB(const CKBehaviorContext& BehContext)
{
	CKBehavior *beh = BehContext.Behavior;

	beh->ActivateInput(0, FALSE);
	beh->ActivateOutput(0);
	
	InputAnalyserMan *man = (InputAnalyserMan*)BehContext.Context->GetManagerByGuid( INPUT_ANALYSER_GUID );
	if (!man){
			BehContext.Context->OutputToConsoleEx("Can't get the InputAnalyser Manager");
			return CKBR_GENERICERROR;
	}
	
	//output volume;
	int vol=(int)man->gem;
	beh->SetOutputParameterValue(0, &vol);

	return CKBR_OK;
}
