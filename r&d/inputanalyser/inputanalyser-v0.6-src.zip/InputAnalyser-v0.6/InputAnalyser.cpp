/////////////////
// InputAnalyzer v0.6 - sphaero.org/KnP
//
// released under the GNU Lesser General Public License (www.gnu.org)
// We ask people when using this library to report this to dev@sphaero.org or wreck@k-n-p.org
// though this is not obliged, just kindly requested.
// People who make additions to this library are also asked to report this so others
// can benefit.

#define INPUT_ANALYSER_BB_GUID	CKGUID( 0x1e454fa3,0x3a215ebf )
#include "CKAll.h"
#include "InputAnalyser.h"

// Frame Count class function definitions
//constructor
InputAnalyserMan::InputAnalyserMan(CKContext *ctx):CKBaseManager(ctx,INPUT_ANALYSER_GUID, MyManagerName)
{
	// Register the manager
	ctx->RegisterNewManager(this);
	
	gem=100;
	snd=0;
	max=0;
	maxi=0;
}

//destructor
CKERROR InputAnalyserMan::OnCKEnd()
{
	sndin_free(snd);
	return CK_OK;
}

//Manager INIT will be run on Virtools Startup
CKERROR InputAnalyserMan::OnCKInit()
{
	snd=sndin_init(44100,1,16,640*1024);
	if(snd==0)
	{
		gem=89;
		sndin_free(snd);
		return CKBR_GENERICERROR;
	}
	fft.Init(BUFSIZE,FFTSIZE);
	return CK_OK;
}

//Reset will be run when Virtools will be reseted (aka rewinded)
CKERROR InputAnalyserMan::OnCKReset()
{
	return CK_OK;
}

//Will be run before the frame is executed and rendered and forms the main execution loop
CKERROR InputAnalyserMan::PreProcess()
{
	if (snd!=0)
	{
		sndin_capture(snd,(void*)sambuffer,BUFSIZE*2);
	}
	else gem = 56;
	for (int i=0;i<BUFSIZE;i++)
	{
		sambf[i]=(float)sambuffer[i];
		gem+=(float)fabs(sambf[i]);
	}
	fft.time_to_frequency_domain(sambf,fftbufs);
	gem=gem/BUFSIZE;

	return CK_OK;
}



//Function to retrieve the average frequency value of the frequency range
float InputAnalyserMan::GetRangeAvg(float *array,int start,int end)
{
  int i;
  int len;
  float f=0;
  float *a;

  if(start>end) return 0;
  if(start==end) return array[start];

  a=&array[start];
  len=end-start;

  for(i=0;i<=len;i++)
    f+=*(a++);

  return (f/(float)len);
}

// function to get the highest value of the frequency range
float InputAnalyserMan::GetRangeMax(float *array,int start,int end)
{
  int i;
  int len;
  float f=0;
  float *a;

  if(start>end) return 0;
  if(start==end) return array[start];

  a=&array[start];
  len=end-start;

  for(i=0;i<=len;i++)
  {
    if(*a>f) f=*a;
    a++;
  }

  return f;
}

// function to convert the frequency into an array number
int InputAnalyserMan::FreqToIndex(int freq,int rate,int fftsize)
{
  int i=0;
  int maxfreq=rate/2;

  if(freq==0) return 0;

  i=(int) ((((float)freq/(float)maxfreq)*(float)fftsize));

  if(i>maxfreq) return fftsize-1;
  if(freq<0) return 0;
  return i;
}

void InputAnalyserMan::GetMaxFreq()
{
	max/=2;
	for (int i=0;i<FFTSIZE;i++)
	{
		if(fftbufs[i]>max) 
		{
			max=fftbufs[i];maxi=i;
		}
	}
}

// END Class functie defenities


