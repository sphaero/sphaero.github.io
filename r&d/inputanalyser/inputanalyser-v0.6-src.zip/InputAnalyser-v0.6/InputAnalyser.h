//InputAnanlyser Class Defenition
#ifndef MyManagerName
#define MyManagerName "SoundInputAnalyser"
#endif
#define INPUT_ANALYSER_GUID CKGUID(0xe685921,0x616c6d7e)
#define BUFSIZE 512
#define FFTSIZE (BUFSIZE/2)

#include "sound.h"
#include "fft.h"


class InputAnalyserMan : public CKBaseManager 
{
public:
	InputAnalyserMan(CKContext *ctx);
	~InputAnalyserMan() {}

	// User Functions
	float GetGem()		 { return gem; }
	short GetSamBuffer(int i) { return sambuffer[i];  }
	float *GetFftBuffer() { return fftbufs;    }
    float GetRangeAvg(float *array,int start,int end);
    float GetRangeMax(float *array,int start,int end);
    int FreqToIndex(int freq,int rate,int fftsize);
	void GetMaxFreq();

	// Virtual overrides
	CKERROR OnCKReset();
	CKERROR PreProcess();
	CKERROR OnCKInit();
	CKERROR OnCKEnd();

	// Valid functions mask
	CKDWORD	GetValidFunctionsMask()	{ return CKMANAGER_FUNC_OnCKReset|
											 CKMANAGER_FUNC_PreProcess|
											 CKMANAGER_FUNC_OnCKInit|
											 CKMANAGER_FUNC_OnCKEnd;}

	//Class vars..
	short sambuffer[BUFSIZE];
	float sambf[BUFSIZE];
	
	float gem;
	float max; 
	int maxi;

	float fftbufs[FFTSIZE];

	float sound_low,sound_mid,sound_high;

	SNDIN *snd;
	FFT fft;

};
