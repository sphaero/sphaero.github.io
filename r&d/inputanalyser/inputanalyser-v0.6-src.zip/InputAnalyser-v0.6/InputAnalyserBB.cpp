// Declarations of the Behavior Building Block
#include "CKAll.h"
#include "InputAnalyser.h"

CKObjectDeclaration	*FillBehaviorIAGetFreqBBDecl();
CKERROR CreateIAGetFreqBBProto(CKBehaviorPrototype **);
int IAGetFreqBB(const CKBehaviorContext& BehContext);

CKERROR InputAnalyserCallBack(const CKBehaviorContext& BehContext);

CKObjectDeclaration	*FillBehaviorIAGetFreqBBDecl()
{
	CKObjectDeclaration *od = CreateCKObjectDeclaration("IAGetFreqBB");	
	
	od->SetType(CKDLL_BEHAVIORPROTOTYPE);
	od->SetVersion(0x00010000);
	od->SetCreationFunction(CreateIAGetFreqBBProto);
	od->SetDescription("Get frequency information in range (range-index=255/freq)");
	od->SetCategory("Sounds/InputAnalyser");
	od->SetGuid(CKGUID(0xF9CBE5A2,0x8F0FAEFF));
	od->SetAuthorGuid(CKGUID(0x56495254,0x4f4f4c53));
	od->SetAuthorName("KnP");
	od->SetCompatibleClassId(CKCID_BEOBJECT);

	return od;
}

CKERROR CreateIAGetFreqBBProto(CKBehaviorPrototype** pproto)
{
	CKBehaviorPrototype *proto = CreateCKBehaviorPrototype("IAGetFreqBB");
	if(!proto) 	return CKERR_OUTOFMEMORY;

//---	Inputs declaration
	proto->DeclareInput("In0");
							
//---	Outputs declaration
	proto->DeclareOutput("Out0");
							
//----- Input Parameters Declaration
	proto->DeclareInParameter("Freq1",CKPGUID_INT,"1");
	proto->DeclareInParameter("Freq2",CKPGUID_INT,"20");
							
//---	Output Parameters Declaration
	proto->DeclareOutParameter("range1",CKPGUID_FLOAT);

//----	Local Parameters Declaration

//----	Settings Declaration
	proto->SetFlags(CK_BEHAVIORPROTOTYPE_NORMAL);
	proto->SetBehaviorFlags((CK_BEHAVIOR_FLAGS)(CKBEHAVIOR_VARIABLEPARAMETERINPUTS|CKBEHAVIOR_INTERNALLYCREATEDOUTPUTPARAMS));
	proto->SetFunction(IAGetFreqBB);

//---- Callback Decl.
	proto->SetBehaviorCallbackFct( InputAnalyserCallBack);

	*pproto = proto;
	return CK_OK;
}

int IAGetFreqBB(const CKBehaviorContext& BehContext)
{
	CKBehavior *beh = BehContext.Behavior;

	beh->ActivateInput(0, FALSE);
	beh->ActivateOutput(0);

//	BehContext.Context->OutputToConsoleEx("Pre manager init");
	
	InputAnalyserMan *man = (InputAnalyserMan*)BehContext.Context->GetManagerByGuid( INPUT_ANALYSER_GUID );
	if (!man){
			BehContext.Context->OutputToConsoleEx("Can't get the InputAnalyser Manager");
			return CKBR_GENERICERROR;
	}
	
	
	int freq_pin_start=0;
	int freq_pin_end=0;
	float range_value;
	int count_param_out=beh->GetOutputParameterCount();
	for(int i=0 ; i<count_param_out ; i++) 
	{	// For first 2 frequency pins do analysis)
		// then move along the input params until all ranges are done
		beh->GetInputParameterValue(i,&freq_pin_start);
		beh->GetInputParameterValue(i+1,&freq_pin_end);
		range_value = man->GetRangeMax(man->fftbufs,freq_pin_start,freq_pin_end);
		beh->SetOutputParameterValue(i, &range_value);
	}
	return CKBR_OK;
}

/*******************************************************/
/*                     CALLBACK                        */
/*******************************************************/
CKERROR InputAnalyserCallBack(const CKBehaviorContext& BehContext){
  
	CKBehavior* beh = BehContext.Behavior;

	switch( BehContext.CallbackMessage ){
	case CKM_BEHAVIOREDITED:
		{
			int c_out = beh->GetOutputParameterCount();
			int c_pin = beh->GetInputParameterCount()-1;
			
			char pin_str[10];
			
			while( c_pin > c_out ){ // we must add Output Params
				sprintf( pin_str, "range%d", c_out+1);
				beh->CreateOutputParameter(pin_str,CKPGUID_FLOAT);
				++c_out;
			}
			
			while( c_pin < c_out ){ // we must remove Output Params
				--c_out;
				BehContext.Context->DestroyObject(beh->RemoveOutputParameter(c_out));
			}
			
		}
		break;
		
	}
	
	return CKBR_OK; 
}