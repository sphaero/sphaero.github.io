/*
  sndin v1.0 by Ronald Hof (wrecK/KnP)

    Quick hack to get the N most recent samples from the default recording device.
    Not very usefull for anything other than analyzing the sound input.

    uses directsound
*/

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#include "dsound.h"

#pragma comment( lib, "dsound.lib" )
#pragma comment( lib, "dxguid.lib" )


struct SNDIN
{
  LPDIRECTSOUNDCAPTURE   pDSCapture;
  LPDIRECTSOUNDCAPTUREBUFFER pDSBCapture;
  LPDIRECTSOUNDNOTIFY        pDSNotify;
  DSCBUFFERDESC      dscbd;
  WAVEFORMATEX     wfx;
  int buffersize;
};

SNDIN *sndin_init(int freq,int chan,int bits,int buffersize);
int sndin_capture(SNDIN *snd,void *buffer,int size);
void sndin_free(SNDIN *snd);

