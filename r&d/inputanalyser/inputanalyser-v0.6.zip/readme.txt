System requirements:

- DirectX 8.1 or higher
- Soundcard installed.
- Virtools 2.x (Virtools 2.5 has not been tested by us)

We've found problems while using Windows '98. Best results were with Windows 2000 which is the target platform


Installation notes:

just copy the DLL into your 'managers' directory. When you start Virtools you will find a new section Building Blocks - Sound - InputAnalyser in which you'll find three Building Blocks:

IAGetFreqBB: This building block will output FFT frequency analysis. The freqeuncy range is 0 - 22KHz. This is divided into 256. You can add input parameters (integers) so you can select a range of frequencies. (i.e. integer 1 and 3 will output a range of about 87 Hz to 261 Hz). From version 2.0 the plugin supports stereo sound. You can set which side to output.

IAGetMaxFreqBB: This Building block will output the array number (number between 0-255) of the frequency most found in the sound. From this number you can calculate the frequency range. (the output number times 87)

IAGetVolBB: This building block will output the volume of the sound. The output is an integer.


License & copyrights:

This plugin is copyright 2003 sphaero.org/KnP. All rights reserved. The plugin has been released under the Gnu Lesser Public License for others to enjoy. 

We would like to know if people are using this plugin for any purpose. If you make modifications or additions to this plugin please let us know so we might include it into future releases of the plugin.

Problems or questions please contact us by email

dev@sphaero.org

http://k-n-p.org
http://www.sphaero.org
