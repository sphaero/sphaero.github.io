/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org/Stichting Lange Poten

	This plugin has been created for a research about historical 
	stereophotographics and stereographics for use in theatrical performances. 
	This research (Het Archief) was initiated by Stichting Lange Poten. 
	(http://www.lange-poten.nl)

    This file is part of Virtools NetSync Manager Building Block.

    NetSync Manager is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    NetSync Manager is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with NetSync Manager; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "sock.h"



void sock_slave_stop(sock_slave_struct *slv)
{
	if(slv==0) return;
  //closesocket(slv->s);
	closesocket(slv->t);
	free(slv->buffer);
	free(slv);
	return;
}
	

sock_slave_struct * sock_slave_start(int port,int timeout)
{
	int i;
	int nodelay=1;
  unsigned long t=0;
	sock_slave_struct *slv=0;
	char initstr[]="KnP\0";

	slv=(sock_slave_struct *)calloc(1,sizeof(sock_slave_struct));
	if(slv==0) return 0;

	slv->s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(slv->s==INVALID_SOCKET)
	{
		free(slv);
		return 0;
	}


	slv->port=port;
	slv->slen = sizeof(slv->r_addr);

	memset((void*)&slv->addr,0,sizeof(slv->addr));
	slv->addr.sin_family=AF_INET;
	//slv->addr.sin_addr=htonl(INADDR_ANY);
	slv->addr.sin_addr.s_addr = htonl(INADDR_ANY);
	slv->addr.sin_port=htons(slv->port);

	i=bind(slv->s,(sockaddr *)&slv->addr,sizeof(slv->addr));
	if(i==SOCKET_ERROR)
	{
		closesocket(slv->s);
		free(slv);
		return 0;
	}

  //printf("listen\n");
	i=listen(slv->s,SOMAXCONN);
	if(i==SOCKET_ERROR)
	{
		closesocket(slv->s);
		free(slv);
		return 0;
	}

  t=1;
  ioctlsocket(slv->s,FIONBIO,&t);

  i=0;
  //printf("accept\n");

  do
  {
	slv->t=accept(slv->s,(sockaddr *)&slv->r_addr,&slv->slen);
	i++;
  //printf("  timeout:%d\n",timeout);
  timeout--;
  Sleep(1000);
  } while (slv->t==INVALID_SOCKET && timeout >0);

  if(slv->t==INVALID_SOCKET)
	{
		closesocket(slv->s);
		free(slv);
		return 0;
	}

  t=0;
  ioctlsocket(slv->t,FIONBIO,&t);
  
  closesocket(slv->s);

	setsockopt(slv->t, IPPROTO_TCP, TCP_NODELAY, (char*)&nodelay, sizeof(nodelay));

	send(slv->t,initstr,strlen(initstr)+1,0);
	recv(slv->t,(char *)&slv->buflen,4,0);
	slv->buffer=calloc(1,slv->buflen);
	if(slv->buffer==0)
	{
		i=0;
		send(slv->t,(char *)&i,4,0);
		closesocket(slv->t);
		closesocket(slv->s);
		free(slv);
		return 0;
	}

	i=1;
	send(slv->t,(char *)&i,4,0);
	return slv;
}

void *sock_slave_getdata(sock_slave_struct *slv,int o)
{
	int i;
	int len;
	i=0;
	send(slv->t,(char *)&o,4,0);
	len=recv(slv->t,(char *)&i,4,0);
	if(i==0) return 0;
	len=recv(slv->t,(char *)slv->buffer,slv->buflen,0);
	return slv->buffer;
}

sock_master_struct * sock_master_start(int buflen,char *host,int port)
{
	sock_master_struct *mst;
	int r;
	char initstr[256];
	int nodelay=1;

	mst=(sock_master_struct *)calloc(1,sizeof(sock_master_struct));
	if(mst==0) return 0;

	mst->buflen=buflen;

	memset((void *)&mst->addr,0,sizeof(mst->addr));
	mst->addr.sin_addr.s_addr=inet_addr(host);
	if(mst->addr.sin_addr.s_addr==INADDR_NONE)
	{
		mst->h=gethostbyname(host);
		if(mst->h==NULL)
		{
			free(mst);
			return 0;
		}
	}
	else
	{
		mst->h=gethostbyaddr((const char *)&mst->addr.sin_addr,sizeof(struct sockaddr_in),AF_INET);
		if(mst->h==NULL)
		{
			free(mst);
			return 0;
		}
	}


	mst->s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(mst->s==INVALID_SOCKET)
	{
		free(mst);
		return 0;
	}


	mst->addr.sin_family=AF_INET;
	//mst->addr.sin_addr=*((in_addr*)*mst->h->h_addr_list);
	mst->addr.sin_addr=*((in_addr*)*mst->h->h_addr_list);
	mst->addr.sin_port=htons(port);

	r=connect(mst->s,(sockaddr *)&mst->addr,sizeof(struct sockaddr));

	
	if(r==SOCKET_ERROR)
	{
		closesocket(mst->s);
		free(mst);
		return 0;
	}

	setsockopt(mst->s, IPPROTO_TCP, TCP_NODELAY, (char*)&nodelay, sizeof(nodelay));

	recv(mst->s,initstr,256,0);
	send(mst->s,(char *)&buflen,4,0);

	recv(mst->s,(char *)&r,4,0);
	if(r==0)
	{
		closesocket(mst->s);
		free(mst);
		return 0;
	}

	return mst;
}

void sock_master_stop(sock_master_struct *mst)
{
	int i;
	if(mst==0) return;
	recv(mst->s,(char *)&i,4,0);
	i=0;
	send(mst->s,(char *)&i,4,0);
	closesocket(mst->s);
	free(mst);
}

int sock_master_senddata(void *data,sock_master_struct *mst)
{
	int i,o;
	recv(mst->s,(char *)&o,4,0);
	i=2;
	send(mst->s,(char *)&i,4,0);
	send(mst->s,(char *)data,mst->buflen,0);
  return o;
}
	




	













	
	