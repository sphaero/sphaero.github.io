/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org/Stichting Lange Poten

	This plugin has been created for a research about historical 
	stereophotographics and stereographics for use in theatrical performances. 
	This research (Het Archief) was initiated by Stichting Lange Poten. 
	(http://www.lange-poten.nl)

    This file is part of Virtools NetSync Manager Building Block.

    NetSync Manager is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    NetSync Manager is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with NetSync Manager; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Declarations of the Behavior Building Block
#ifndef VNETWORK_GUID
#define VNETWORK_GUID	CKGUID( 0x668b60e3,0x3ca3273b )
#endif
#ifndef VNSLAVE_BB_GUID
#define VNSLAVE_BB_GUID		CKGUID( 0x11dc02fc,0x3eb05b34 )
#endif
#ifndef VNMASTER_BB_GUID
#define VNMASTER_BB_GUID	CKGUID( 0x2ec63163,0x17e36f58 )
#endif
#ifndef VNCLIENT_BB_GUID
#define VNCLIENT_BB_GUID	CKGUID( 0x25e8104d,0x2eb00000 )
#endif
#ifndef VNEYWSERVER_BB_GUID
#define VNEYWSERVER_BB_GUID	CKGUID(0xcc5538d,0x69d565c1)
#endif
#ifndef MyManagerName
#define MyManagerName "VirtoolsNetworkManager"
#endif

#include "CKAll.h"
#include "VNetTCP.h"

CKObjectDeclaration	*FillBehaviorNS_ClientDecl();
CKERROR CreateNS_ClientProto(CKBehaviorPrototype **);
int NS_Client(const CKBehaviorContext& BehContext);

CKERROR NS_ClientCallBack(const CKBehaviorContext& BehContext);

CKObjectDeclaration	*FillBehaviorNS_ClientDecl()
{
	CKObjectDeclaration *od = CreateCKObjectDeclaration("NS_Client");	
	
	od->SetType(CKDLL_BEHAVIORPROTOTYPE);
	od->NeedManager(VNETWORK_GUID);
	od->SetVersion(0x00010000);
	od->SetCreationFunction(CreateNS_ClientProto);
	od->SetDescription("is a TCP socket client");
	od->SetCategory("Net");
	od->SetGuid(VNCLIENT_BB_GUID);
	od->SetAuthorGuid(CKGUID(0x56495254,0x4f4f4c53));
	od->SetAuthorName("AAUC :)n");
	od->SetCompatibleClassId(CKCID_BEOBJECT);

	return od;
}

CKERROR CreateNS_ClientProto(CKBehaviorPrototype** pproto)
{
	CKBehaviorPrototype *proto = CreateCKBehaviorPrototype("NS_Client");
	if(!proto) 	return CKERR_OUTOFMEMORY;

//---	Inputs declaration
	proto->DeclareInput("In0");
	proto->DeclareInput("InputSendSignal");
							
//---	Outputs declaration
	proto->DeclareOutput("Out0");
							
//----- Input Parameters Declaration
	proto->DeclareInParameter( "SendString", CKPGUID_STRING, "" );

//---	Output Parameters Declaration
	proto->DeclareOutParameter("01", CKPGUID_VECTOR);
	proto->DeclareOutParameter("02", CKPGUID_MATRIX);
	proto->DeclareOutParameter("OutChar", CKPGUID_STRING);
	proto->DeclareOutParameter("OutInt", CKPGUID_INT);

//----	Local Parameters Declaration

//----	Settings Declaration
	proto->DeclareSetting("start_socket",CKPGUID_BOOL,"0");
	proto->DeclareSetting("port",CKPGUID_INT, "31337");
	proto->DeclareSetting("timeout(sec)", CKPGUID_INT, "10");
	//IP addr is string 
	proto->DeclareSetting("IP Adress",CKPGUID_STRING, "192.168.0.2");

	proto->SetFlags(CK_BEHAVIORPROTOTYPE_NORMAL);
	proto->SetBehaviorFlags((CK_BEHAVIOR_FLAGS)(CKBEHAVIOR_WAITSFORMESSAGE));
	proto->SetFunction(NS_Client);

//----  Callback Decl.
	proto->SetBehaviorCallbackFct( NS_ClientCallBack);

	*pproto = proto;
	return CK_OK;
}

int NS_Client(const CKBehaviorContext& BehContext)
{
	CKBehavior *beh = BehContext.Behavior;

	beh->ActivateInput(0, FALSE);
	beh->ActivateOutput(0);

	
	VNetworkMan *man = (VNetworkMan*)BehContext.Context->GetManagerByGuid( VNETWORK_GUID );
	if (!man){
			BehContext.Context->OutputToConsoleEx("Can't get the Network Manager");
			return CKBR_GENERICERROR;
	}


	if (man->VN_IsSocketSetOn() )
	{ 
		int size;
		int i;
		int ConvVal; 

		
		//check if button pressed for sending
		if (beh->IsInputActive(1))
		{
			beh->ActivateInput(1, FALSE);
			
			char String_to_Send[512];
			beh->GetInputParameterValue(0,&String_to_Send);
			i = sock_client_senddata(String_to_Send, man->clt, BehContext.Context);
			BehContext.Context->OutputToConsoleEx(" SENDING TO MAX %s", String_to_Send);			
			
		}
		
		//process the received
		
		CKCHAR RecBuff[512]= "a\0";
		strcpy(RecBuff,man->inCharP);

		size = strlen(RecBuff);
		if (size == 0)
			{
			strcpy(RecBuff," \0");		
			}
		else
			{
			//put an integer on the output
			i = sscanf(RecBuff, "%d", &ConvVal);
			beh->SetOutputParameterValue(3, &ConvVal);	
			}

		beh->SetOutputParameterValue(2, &RecBuff);	
		
		BehContext.Context->OutputToConsoleEx(" CLIENT - socket set on: %s . %d", RecBuff, size );			
		
	}
	
	//BehContext.Context->OutputToConsoleEx(" CLIENT - socket NOT set on");	
	return CKBR_OK;
}

//********************************
// CALLBACK
//********************************

CKERROR NS_ClientCallBack(const CKBehaviorContext& BehContext){
  
	CKBehavior* beh = BehContext.Behavior;

	VNetworkMan *man = (VNetworkMan*)BehContext.Context->GetManagerByGuid( VNETWORK_GUID );
	if (!man){
		BehContext.Context->OutputToConsoleEx("Can't get the Network Manager");
		return CKBR_GENERICERROR;
	}

	switch( BehContext.CallbackMessage )
	{
		case CKM_BEHAVIORSETTINGSEDITED:
		case CKM_BEHAVIOREDITED:
		{
			bool BB_start_socket;
			beh->GetLocalParameterValue(0,&BB_start_socket);
			man->VN_SocketStart(BB_start_socket);

			int BB_port;
			beh->GetLocalParameterValue(1,&BB_port);
			man->VN_SetPort(BB_port);
			
			int BB_timeout;
			beh->GetLocalParameterValue(2,&BB_timeout);
			man->VN_SetTimeOut(BB_timeout);
			
			char BB_IpAdress[256];
			beh->GetLocalParameterValue(3,&BB_IpAdress);
			man->VN_SetHostname(BB_IpAdress);

			BehContext.Context->OutputToConsoleEx("Network Manager: CLIENT Beh edited");
			
			break;
		}
		case CKM_BEHAVIORATTACH:
		case CKM_BEHAVIORLOAD:
		{
			bool BB_start_socket;
			beh->GetLocalParameterValue(0,&BB_start_socket);
			man->VN_SocketStart(BB_start_socket);

			int BB_port;
			beh->GetLocalParameterValue(1,&BB_port);
			man->VN_SetPort(BB_port);
			
			int BB_timeout;
			beh->GetLocalParameterValue(2,&BB_timeout);
			man->VN_SetTimeOut(BB_timeout);

			char BB_IpAdress[256];
			beh->GetLocalParameterValue(3,&BB_IpAdress);
			man->VN_SetHostname(BB_IpAdress);

			bool BB_client = true;
			
			int ah = 2;

			man->VN_SetNetModus(ah);
			man->VN_SetClient(BB_client);
			

			BehContext.Context->OutputToConsoleEx("Network Manager: Set to CLIENT");
			
			break;
		}
		case CKM_BEHAVIORDELETE:
		case CKM_BEHAVIORDETACH:
		{
			BehContext.Context->OutputToConsoleEx("Network Manager: closing socket");

			bool BB_socketstart = false;
			man->VN_SocketStart(BB_socketstart);
			
			break;
		}
		default:
			break;
	}
	return CKBR_OK; 
}