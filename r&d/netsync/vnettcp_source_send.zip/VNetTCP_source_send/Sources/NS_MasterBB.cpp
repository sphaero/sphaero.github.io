/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org/Stichting Lange Poten

	This plugin has been created for a research about historical 
	stereophotographics and stereographics for use in theatrical performances. 
	This research (Het Archief) was initiated by Stichting Lange Poten. 
	(http://www.lange-poten.nl)

    This file is part of Virtools NetSync Manager Building Block.

    NetSync Manager is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    NetSync Manager is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with NetSync Manager; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


// Declarations of the Behavior Building Block
#ifndef VNETWORK_GUID
#define VNETWORK_GUID	CKGUID( 0x668b60e3,0x3ca3273b )
#endif
#ifndef VNSLAVE_BB_GUID
#define VNSLAVE_BB_GUID		CKGUID( 0x11dc02fc,0x3eb05b34 )
#endif
#ifndef VNMASTER_BB_GUID
#define VNMASTER_BB_GUID	CKGUID( 0x2ec63163,0x17e36f58 )
#endif
#ifndef VNCLIENT_BB_GUID
#define VNCLIENT_BB_GUID	CKGUID( 0x25e8104d,0x2eb00000 )
#endif
#ifndef VNEYWSERVER_BB_GUID
#define VNEYWSERVER_BB_GUID	CKGUID(0xcc5538d,0x69d565c1)
#endif
#ifndef MyManagerName
#define MyManagerName "VirtoolsNetworkManager"
#endif

#include "CKAll.h"
#include "VNetTCP.h"

CKObjectDeclaration	*FillBehaviorNS_MasterDecl();
CKERROR CreateNS_MasterProto(CKBehaviorPrototype **);
int NS_Master(const CKBehaviorContext& BehContext);

CKERROR NS_MasterCallBack(const CKBehaviorContext& BehContext);

CKObjectDeclaration	*FillBehaviorNS_MasterDecl()
{
	CKObjectDeclaration *od = CreateCKObjectDeclaration("NS_Master");	
	
	od->SetType(CKDLL_BEHAVIORPROTOTYPE);
	od->NeedManager(VNETWORK_GUID);
	od->SetVersion(0x00010000);
	od->SetCreationFunction(CreateNS_MasterProto);
	od->SetDescription("Edits and sets NetSync MASTER mode");
	od->SetCategory("Net");
	od->SetGuid(VNMASTER_BB_GUID);
	od->SetAuthorGuid(CKGUID(0x56495254,0x4f4f4c53));
	od->SetAuthorName("KnP");
	od->SetCompatibleClassId(CKCID_BEOBJECT);

	return od;
}

CKERROR CreateNS_MasterProto(CKBehaviorPrototype** pproto)
{
	CKBehaviorPrototype *proto = CreateCKBehaviorPrototype("NS_Master");
	if(!proto) 	return CKERR_OUTOFMEMORY;

//---	Inputs declaration
	proto->DeclareInput("In0");
							
//---	Outputs declaration
	proto->DeclareOutput("Out0");
							
//----- Input Parameters Declaration
	proto->DeclareInParameter("01", CKPGUID_VECTOR);
	proto->DeclareInParameter("02", CKPGUID_MATRIX);
//	proto->DeclareInParameter("02", CKPGUID_VECTOR);
//	proto->DeclareInParameter("03", CKPGUID_VECTOR);
//	proto->DeclareInParameter("04", CKPGUID_VECTOR);
//	proto->DeclareInParameter("05", CKPGUID_VECTOR);
							
//---	Output Parameters Declaration
	proto->DeclareOutParameter("master/slave status",CKPGUID_BOOL);

//----	Local Parameters Declaration

//----	Settings Declaration
	proto->DeclareSetting("start_socket",CKPGUID_BOOL,"0");
	proto->DeclareSetting("host address",CKPGUID_STRING, "127.0.0.1");
	proto->DeclareSetting("port",CKPGUID_INT, "6868");
	
	proto->SetFlags(CK_BEHAVIORPROTOTYPE_NORMAL);
	proto->SetBehaviorFlags((CK_BEHAVIOR_FLAGS)(CKBEHAVIOR_WAITSFORMESSAGE));//|CKBEHAVIOR_VARIABLEPARAMETERINPUTS|CKBEHAVIOR_INTERNALLYCREATEDOUTPUTPARAMS));
	proto->SetFunction(NS_Master);

//----  Callback Decl.
	proto->SetBehaviorCallbackFct( NS_MasterCallBack);

	*pproto = proto;
	return CK_OK;
}

int NS_Master(const CKBehaviorContext& BehContext)
{
	CKBehavior *beh = BehContext.Behavior;

	beh->ActivateInput(0, FALSE);
	beh->ActivateOutput(0);

	VNetworkMan *man = (VNetworkMan*)BehContext.Context->GetManagerByGuid( VNETWORK_GUID );
	if (!man){
			BehContext.Context->OutputToConsoleEx("Can't get the Network Manager");
			return CKBR_GENERICERROR;
	}
	
	if (man->VN_IsSocketSetOn() )
	{
		//just to make sure the manager is set to master
		if ( man->VN_IsSlave() )
		{
			BehContext.Context->OutputToConsoleEx("Weird, manager seems set to slave, ERROR");
		}
		else
		{	
			VxVector BB_pre_out;
			beh->GetInputParameterValue(0,&BB_pre_out);
			man->out[1]=BB_pre_out.x;
			man->out[2]=BB_pre_out.y;
			man->out[3]=BB_pre_out.z;
			
			VxMatrix BB_pre_out2;
			beh->GetInputParameterValue(1,&BB_pre_out2);
			for (int i=0;i<4;i++)
			{
				for (int j=0;j<4;j++)
				{
					man->out[((i*4)+j+4)] = BB_pre_out2[i][j];
				}
			}
		}
	}
	beh->SetOutputParameterValue(0, &man->netmode);
	
	return CKBR_OK;
}

//********************************
// CALLBACK
//********************************

CKERROR NS_MasterCallBack(const CKBehaviorContext& BehContext){
  
	CKBehavior* beh = BehContext.Behavior;
	
	VNetworkMan *man = (VNetworkMan*)BehContext.Context->GetManagerByGuid( VNETWORK_GUID );
	if (!man){
		BehContext.Context->OutputToConsoleEx("Can't get the Network Manager");
		return CKBR_GENERICERROR;
	}

	switch( BehContext.CallbackMessage )
	{
		case CKM_BEHAVIORSETTINGSEDITED:
		case CKM_BEHAVIOREDITED:
		{
			bool BB_start_socket;
			beh->GetLocalParameterValue(0,&BB_start_socket);
			man->VN_SocketStart(BB_start_socket);
			
			char BB_hostname[256];
			beh->GetLocalParameterValue(1,&BB_hostname);
			man->VN_SetHostname(BB_hostname);

			int BB_port;
			beh->GetLocalParameterValue(2,&BB_port);
			man->VN_SetPort(BB_port);

			break;
		}
		case CKM_BEHAVIORATTACH:
		case CKM_BEHAVIORLOAD:
		{
			bool BB_start_socket;
			beh->GetLocalParameterValue(0,&BB_start_socket);
			man->VN_SocketStart(BB_start_socket);
			
			char BB_hostname[256];
			beh->GetLocalParameterValue(1,&BB_hostname);
			man->VN_SetHostname(BB_hostname);

			int BB_port;
			beh->GetLocalParameterValue(2,&BB_port);
			man->VN_SetPort(BB_port);
			
			bool BB_slave = false;
			//man->VN_SetModus(BB_slave);
			int ah = 0;
			man->VN_SetNetModus(ah);

			BehContext.Context->OutputToConsoleEx("Network Manager: Set to MASTER");
			
			break;
		}
		case CKM_BEHAVIORDELETE:
		case CKM_BEHAVIORDETACH:
		{
			BehContext.Context->OutputToConsoleEx("Network Manager: closing socket");
			
			bool BB_socketstart = false;
			man->VN_SocketStart(BB_socketstart);
		}
		default:
			break;
	}
	
	return CKBR_OK; 
}