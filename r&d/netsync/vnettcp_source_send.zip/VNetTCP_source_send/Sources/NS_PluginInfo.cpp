/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org/Stichting Lange Poten

	This plugin has been created for a research about historical 
	stereophotographics and stereographics for use in theatrical performances. 
	This research (Het Archief) was initiated by Stichting Lange Poten. 
	(http://www.lange-poten.nl)

    This file is part of Virtools NetSync Manager Building Block.

    NetSync Manager is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    NetSync Manager is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with NetSync Manager; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	############################
	# Changelog
	############################
	
	# v1.02b 14-01-04
	- fixed mixed up defines

	# v1.01b 13-01-04
	- fixed master socket start when not set on

*/

#ifndef VNETWORK_GUID
#define VNETWORK_GUID	CKGUID( 0x668b60e3,0x3ca3273b )
#endif
#ifndef VNSLAVE_BB_GUID
#define VNSLAVE_BB_GUID		CKGUID( 0x11dc02fc,0x3eb05b34 )
#endif
#ifndef VNMASTER_BB_GUID
#define VNMASTER_BB_GUID	CKGUID( 0x2ec63163,0x17e36f58 )
#endif
#ifndef VNCLIENT_BB_GUID
#define VNCLIENT_BB_GUID	CKGUID( 0x25e8104d,0x2eb00000 )
#endif
#ifndef VNEYWSERVER_BB_GUID
#define VNEYWSERVER_BB_GUID	CKGUID(0xcc5538d,0x69d565c1)
#endif
#ifndef MyManagerName
#define MyManagerName "VirtoolsNetworkManager"
#endif

#include "CKAll.h"
#include "VNetTCP.h"

//Virtools Plugin info

// Manager INIT
CKERROR InitVNetworkMan(CKContext *ctx)
{
	new VNetworkMan(ctx);
	return CK_OK;
}

// Manager EXIT
CKERROR ExitVNetworkMan(CKContext *ctx)
{
	VNetworkMan *man=(VNetworkMan*)ctx->GetManagerByName(MyManagerName);
	delete man;
	return CK_OK;
}

CKPluginInfo g_PluginInfo[4];

int CKGetPluginInfoCount() { return 4; }

CKPluginInfo *CKGetPluginInfo(int Index)
{
			g_PluginInfo[0].m_Author			= "KnP";
			g_PluginInfo[0].m_Description		= "Opens a network socket";
			g_PluginInfo[0].m_Extension			= "";
			g_PluginInfo[0].m_Type				= CKPLUGIN_MANAGER_DLL;
			g_PluginInfo[0].m_Version			= 0x000001;
			g_PluginInfo[0].m_InitInstanceFct	= InitVNetworkMan;
			g_PluginInfo[0].m_ExitInstanceFct	= ExitVNetworkMan;
			g_PluginInfo[0].m_GUID				= VNETWORK_GUID;
			g_PluginInfo[0].m_Summary			= MyManagerName;

			g_PluginInfo[1].m_Author			= "KnP";
			g_PluginInfo[1].m_Description		= "Edits and sets NetSync SLAVE mode";
			g_PluginInfo[1].m_Extension			= "";
			g_PluginInfo[1].m_Type				= CKPLUGIN_BEHAVIOR_DLL;
			g_PluginInfo[1].m_Version			= 0x00010000;
			g_PluginInfo[1].m_InitInstanceFct	= NULL; //
			g_PluginInfo[1].m_GUID				= VNSLAVE_BB_GUID;
			g_PluginInfo[1].m_Summary			= "Edits and sets NetSync SLAVE mode";

			g_PluginInfo[2].m_Author			= "KnP";
			g_PluginInfo[2].m_Description		= "Edits and sets NetSync MASTER mode";
			g_PluginInfo[2].m_Extension			= "";
			g_PluginInfo[2].m_Type				= CKPLUGIN_BEHAVIOR_DLL;
			g_PluginInfo[2].m_Version			= 0x00010000;
			g_PluginInfo[2].m_InitInstanceFct	= NULL; //
			g_PluginInfo[2].m_GUID				= VNMASTER_BB_GUID;
			g_PluginInfo[2].m_Summary			= "Edits and sets NetSync MASTER mode";

			g_PluginInfo[3].m_Author			= "AAUC :)n";
			g_PluginInfo[3].m_Description		= "is a TCP socket client";
			g_PluginInfo[3].m_Extension			= "";
			g_PluginInfo[3].m_Type				= CKPLUGIN_BEHAVIOR_DLL;
			g_PluginInfo[3].m_Version			= 0x00010000;
			g_PluginInfo[3].m_InitInstanceFct	= NULL; //
			g_PluginInfo[3].m_GUID				= VNCLIENT_BB_GUID;
			g_PluginInfo[3].m_Summary			= "is a TCP socket client";

			g_PluginInfo[4].m_Author			= "AAUC :)n";
			g_PluginInfo[4].m_Description		= "is a TCP socket listening server {dev for EyesWeb}";
			g_PluginInfo[4].m_Extension			= "";
			g_PluginInfo[4].m_Type				= CKPLUGIN_BEHAVIOR_DLL;
			g_PluginInfo[4].m_Version			= 0x00010000;
			g_PluginInfo[4].m_InitInstanceFct	= NULL; //
			g_PluginInfo[4].m_GUID				= VNEYWSERVER_BB_GUID;
			g_PluginInfo[4].m_Summary			= "is a TCP socket listening server {dev for EyesWeb}";

			return &g_PluginInfo[Index];
}

CKObjectDeclaration	*FillBehaviorNS_SlaveDecl();
CKObjectDeclaration *FillBehaviorNS_MasterDecl();
CKObjectDeclaration *FillBehaviorNS_ClientDecl();
CKObjectDeclaration *FillBehaviorNS_EYWServerDecl();
// Additionnal behaviors definitions should be added here....

//	This function should be present and exported for Virtools
//	to be able to retrieve objects declarations.
//	Virtools will call this function at initialization
void RegisterBehaviorDeclarations(XObjectDeclarationArray *reg)
{
	reg->PushBack(FillBehaviorNS_SlaveDecl());
	reg->PushBack(FillBehaviorNS_MasterDecl());
	reg->PushBack(FillBehaviorNS_ClientDecl());
	reg->PushBack(FillBehaviorNS_EYWServerDecl());
// Additionnal behaviors registrations should be added here....
}