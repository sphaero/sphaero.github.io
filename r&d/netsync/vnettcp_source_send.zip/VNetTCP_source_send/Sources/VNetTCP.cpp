/*	
	Copyright (C) 2003, 2004 k-n-p.org/sphaero.org/Stichting Lange Poten

	This plugin has been created for a research about historical 
	stereophotographics and stereographics for use in theatrical performances. 
	This research (Het Archief) was initiated by Stichting Lange Poten. 
	(http://www.lange-poten.nl)

    This file is part of Virtools NetSync Manager Building Block.

    NetSync Manager is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    NetSync Manager is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with NetSync Manager; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#ifndef VNETWORK_GUID
#define VNETWORK_GUID	CKGUID( 0x668b60e3,0x3ca3273b )
#endif
#ifndef VNSLAVE_BB_GUID
#define VNSLAVE_BB_GUID		CKGUID( 0x11dc02fc,0x3eb05b34 )
#endif
#ifndef VNMASTER_BB_GUID
#define VNMASTER_BB_GUID	CKGUID( 0x2ec63163,0x17e36f58 )
#endif
#ifndef VNCLIENT_BB_GUID
#define VNCLIENT_BB_GUID	CKGUID( 0x25e8104d,0x2eb00000 )
#endif
#ifndef VNEYWSERVER_BB_GUID
#define VNEYWSERVER_BB_GUID	CKGUID(0xcc5538d,0x69d565c1)
#endif
#ifndef MyManagerName
#define MyManagerName "VirtoolsNetworkManager"
#endif

#include "CKAll.h"
#include "VNetTCP.h"

//constructor
VNetworkMan::VNetworkMan(CKContext *ctx):CKBaseManager(ctx,VNETWORK_GUID, MyManagerName)
{
	// Register the manager
	ctx->RegisterNewManager(this);

	//initialise variables
	//assuming host can carry two connections at once?
	sprintf(host, "127.0.0.1");
	port=6868;
	timeout=10;
	
	//client/server takes precedence
	//new var - server 
	//new var - client
	client = false;
	server = false;
	netmode = 0;
	
	slv_on=false;
	mst_on=false;
	clt_on=false;
	srv_on=false;
	socket_on=false;

	//set status code
	out[0]=0;
	status=4; //Virtools sents reset on first play... this bypasses it
	framecount=0;

	//This will tell windows to access the WinSock subsystem
	//and sets the version to use
	WSADATA wsa_data;
    WSAStartup(MAKEWORD(1,1), &wsa_data);
}

//destructor
CKERROR VNetworkMan::OnCKEnd()
{
	//We no longer need to access the WinSock subsystem
	switch (netmode)
	{
		case 0:
		{
			//master
			VN_master_stop();
			break;
		}
		
		case 1:
		{
			//slave
			VN_slave_stop();
			break;
		}
		
		case 2:
		{
			//socket mode - client or server(list.)
			//client and server can be concurrent = do not switch
			
			//client
			if (client) VN_client_stop();
			//server
			if (server) VN_server_stop();
			
			break;
		}

	}
	

	
	
    WSACleanup();
	return CK_OK;
}

//Manager INIT will be run on Virtools Startup
CKERROR VNetworkMan::OnCKInit()
{
	slv_on=0;
	mst_on=0;
	clt_on=0;
	srv_on=0;


	return CK_OK;
}

CKERROR VNetworkMan::OnCKPlay()
{
	if (socket_on)
	{
		switch (netmode)
		{
			case 0:
			{
				//master
				VN_master_start();
				out[0]=2;
				break;
			}
			
			case 1:
			{
				//slave
				VN_slave_start();
				break;
			}
			
			case 2:
			{
				//socket mode - client or server(list.)
				//client and server can be concurrent = do not switch
				
				//client
				if (client) VN_client_start();
				//server
				if (server) VN_server_start();
							
				break;
			}
	
		}
	}
	
	
	
	return CK_OK;
}

CKERROR VNetworkMan::OnCKPause()
{

	switch (netmode)
	{
		case 0:
		{
			//master
			if (mst_on) 
			{
				out[0]=3;
				sock_master_senddata(&out,mst);
				VN_master_stop();
			}
			break;
		}
		
		case 1:
		{
			//slave
			if (slv_on) VN_slave_stop();
			break;
		}
		
		case 2:
		{
			//socket mode - client or server(list.)
			//client and server can be concurrent = do not switch
			
			//client
			if (client) 
				{
				if (clt_on) VN_client_stop();
				m_Context->OutputToConsole("client stop passed");
				}
			//server
			if (server)
				{
				if (srv_on) VN_server_stop();
				m_Context->OutputToConsole("server stop passed");
				}
					
			break;
		}

	}

	
	return CK_OK;
}

//Reset will be run when Virtools will be reseted (aka rewinded or IC)
CKERROR VNetworkMan::OnCKReset()
{

	switch (netmode)
	{
		case 0:
		{
			//master
			if (mst_on) 
			{
				out[0]=4;
				sock_master_senddata(&out,mst);
				VN_master_stop();
			}
			break;
		}
		
		case 1:
		{
			//slave
			if (slv_on) VN_slave_stop();
			break;
		}
		
		case 2:
		{
			//socket mode - client or server(list.)
			//client and server can be concurrent = do not switch
			
			//client
			if (client) 
				{
				if (clt_on) VN_client_stop();
				}
			//server
			if (server)
				{
				if (srv_on) VN_server_stop();
				}
					
			break;
		}

	}

	
	return CK_OK;
}

//Will be run before the frame is executed and rendered and forms the main execution loop
CKERROR VNetworkMan::PreProcess()
{

	//m_Context->OutputToConsoleEx("PreProcess: %d, client: %d, server %d ", netmode, client, server );
	
	switch (netmode)
	{
		case 0:
		{
			//master
			if (mst_on) 
			{
				sock_master_senddata(&out,mst);
				framecount++;
			}
			break;
		}
		
		case 1:
		{
			//slave
			if (slv_on)
			{
				in=(float *)sock_slave_getdata(slv,timeout);
				framecount++;
				VN_enslaving();
			}
			
			break;
		}
		
		case 2:
		{
			//socket mode - client or server(list.)
			//client and server can be concurrent = do not switch
			
			//client
			if (client) 
				{
				if (clt_on) 
					{
					inCharP = sock_client_getdata(clt, timeout, m_Context);
					}
				else
					{
					//clt not on, try to start again
					//locks - temp comment out?
					//VN_client_start(); //now works?
					}
				}
				
			//m_Context->OutputToConsole("client passed");

			//server
			if (server)
				{
				if (srv_on)
					{
					
					inCharP_serv = (char *)sock_server_getdata(srv, timeout, m_Context);
					
					}
				else
					{

					//m_Context->OutputToConsoleEx("Ever comming????..");
					//VN_server_start();
					}
				}

			//m_Context->OutputToConsole("server passed");
			//no char* pointers or else :) 
			char raport[256]; 
			char tempraport[256];
			strcpy(raport,"");
			
			if (client)
			{
				if (clt_on)  // because of preprocess err
					{
					
					//gives error preprocess if not previously connected!
					sprintf(tempraport," client %s --- %s ", clt->cbuffer, inCharP);
					strcat(raport, tempraport);
					}
				else
					{
					strcpy(tempraport," client: no Max/MSP server ");
					strcat(raport, tempraport);
					}
			}

			//m_Context->OutputToConsole("if client passed");
			if (server)
			{
				if (srv_on)
					{
					//strcpy(tempraport," yes server ", );
					sprintf(tempraport," server: got %d ", srv->buflen);
					strcat(raport, tempraport);
					}
				else
					{
					strcpy(tempraport," server: no EyesWeb client ");
					strcat(raport, tempraport);
					}
			}

			framecount++;
			break;
		}

	}
	
	
	return CK_OK;
}

// Start master
int VNetworkMan::VN_master_start()
{
	if (mst_on) VN_master_stop();
	m_Context->OutputToConsole("VNetwork: Opening master socket");
	mst=sock_master_start(sizeof(float[20]),host,port);
	if(mst==0)
	{
		m_Context->OutputToConsole("Opening master socket failed... Did you run the slave prior to running the master?");
		return 1;
	}
	else 
	{
		mst_on=1;
		out[0]=1;
	}
	return 0;
}

//Stop Master
void VNetworkMan::VN_master_stop()
{
	m_Context->OutputToConsole("VNetwork: Closing master socket");
	m_Context->OutputToConsoleEx("VNetwork: counted %d frames", framecount);
	sock_master_stop(mst);
	mst_on=0;
	out[0]=0;
	framecount=0;
}

//Start slave
int VNetworkMan::VN_slave_start()
{
	if (slv_on) VN_slave_stop();
	m_Context->OutputToConsole("VNetwork: Waiting for master...");
	slv=sock_slave_start(port,timeout);
	if(slv==0)
	{
		m_Context->OutputToConsole("Opening slave socket failed");
		return 1;
	}
	else
	{
		m_Context->OutputToConsole("VNetwork: Master found");
		slv_on=1;
		in[0]=4;
	}
	return 0;
}

//stop slave
void VNetworkMan::VN_slave_stop()
{
	m_Context->OutputToConsole("VNetwork: Closing slave socket");
	m_Context->OutputToConsoleEx("VNetwork: counted %d frames", framecount);
	sock_slave_stop(slv);
	slv_on=0;
	in[0]=1;
}

//Enslaving function checks the status which is received from master [0]
void VNetworkMan::VN_enslaving()
{
	if (!(status==(int)(in[0])))
	{
		status=(int)(in[0]);
		switch (status) 
		{
		case 0: 
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Socket Dead", in[0]);
			break;
		case 1:
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Socket Alive", in[0]);
			break;
		case 2:
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Master sends Play", in[0]);
			break;
		case 3:
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Master sends Pause", in[0]);
			m_Context->Pause();
			//m_Context->Process();
			break;
		case 4:
			m_Context->OutputToConsoleEx("VNetworkSlave: %d = Master sends Reset", in[0]);
			m_Context->Reset();
			//m_Context->Process();
			break;
		default:
		    m_Context->OutputToConsoleEx("VNetworkSlave: %d = This should not be printed. Illegal status code", in[0]);
			break;
		}
	}
	else status=(int)(in[0]);
}

//Start client
int VNetworkMan::VN_client_start()
{

	if (clt_on) VN_client_stop();
	
	m_Context->OutputToConsole("VNetwork: Opening client socket");
	
	clt=sock_client_start(host,port);
	if(clt==0)
	{
		m_Context->OutputToConsole("Opening client socket failed... ");
		return 1;
	}
	else 
	{
		clt_on=1;
		//out[0]=1;
	}
	m_Context->OutputToConsole("VNetwork: OK opening client socket");
	return 0;
}

//stop client
void VNetworkMan::VN_client_stop()
{
	m_Context->OutputToConsole("VNetwork: Closing client socket. Client stopped...");
	sock_client_stop(clt);
	clt_on = 0;
	//???? on the respective behaviour????
	//out[0]=0;
	framecount=0;
}


//Start server
int VNetworkMan::VN_server_start()
{
	if (srv_on) VN_server_stop();
	
	m_Context->OutputToConsole("VNetwork: Opening server socket");
	
	srv = sock_server_start(srvport,srvtimeout, m_Context);
	m_Context->OutputToConsole("VNetwork: server gotcha");
	if(srv==0)
	{
		m_Context->OutputToConsole("Opening server socket failed... ");
		return 1;
	}
	else 
	{
		srv_on=1;
		//out[0]=1;
	}
	m_Context->OutputToConsole("VNetwork: OK opening server socket");
	return 0;
}




//stop server
void VNetworkMan::VN_server_stop()
{
	m_Context->OutputToConsole("VNetwork: Closing server socket");
	//m_Context->OutputToConsoleEx("VNetwork: counted %d frames", framecount);
	sock_server_stop(srv);
	srv_on=0;
	//in[0]=0;   //this one problems the stop because in[0] is master/slave status anyways
	framecount=0;


}



// Some control functions
void VNetworkMan::VN_SocketStart(bool set_on)
{
	socket_on = set_on;
}

bool VNetworkMan::VN_IsSocketSetOn()
{
	return socket_on;
}

void VNetworkMan::VN_ServSocketStart(bool set_on)
{
	servsocket_on = set_on;
}

bool VNetworkMan::VN_IsServSocketSetOn()
{
	return servsocket_on;
}


int VNetworkMan::VN_IsSlave()
{
	return netmode;
}

//void VNetworkMan::VN_SetModus(bool set_modus)
//changed
void VNetworkMan::VN_SetNetModus(int set_modus)
{
	netmode = set_modus;
}

void VNetworkMan::VN_SetClient(bool set_modus)
{
	client = set_modus;
}

void VNetworkMan::VN_SetServer(bool set_modus)
{
	server = set_modus;
}

void VNetworkMan::VN_SetHostname(char set_hostname[256])
{
	sprintf(host, set_hostname);
}

void VNetworkMan::VN_SetPort(int set_portnumber)
{
	port = set_portnumber;
}

void VNetworkMan::VN_SetTimeOut(int set_timeout)
{
	timeout = set_timeout;
}


void VNetworkMan::VN_SetServPort(int set_portnumber)
{
	srvport = set_portnumber;
}

void VNetworkMan::VN_SetServTimeOut(int set_timeout)
{
	srvtimeout = set_timeout;
}
