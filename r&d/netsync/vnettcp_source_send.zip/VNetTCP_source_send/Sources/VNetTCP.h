//Network Manager Class Defenition
#ifndef VNETWORK_GUID
#define VNETWORK_GUID	CKGUID( 0x668b60e3,0x3ca3273b )
#endif
#ifndef VNSLAVE_BB_GUID
#define VNSLAVE_BB_GUID		CKGUID( 0x11dc02fc,0x3eb05b34 )
#endif
#ifndef VNMASTER_BB_GUID
#define VNMASTER_BB_GUID	CKGUID( 0x2ec63163,0x17e36f58 )
#endif
#ifndef VNCLIENT_BB_GUID
#define VNCLIENT_BB_GUID	CKGUID( 0x25e8104d,0x2eb00000 )
#endif
#ifndef VNEYWSERVER_BB_GUID
#define VNEYWSERVER_BB_GUID	CKGUID(0xcc5538d,0x69d565c1)
#endif
#ifndef MyManagerName
#define MyManagerName "VirtoolsNetworkManager"
#endif

#include "sock.h"

class VNetworkMan : public CKBaseManager 
{
public:
	VNetworkMan(CKContext *ctx);
	~VNetworkMan() {}

	// User Functions
	int VN_master_start();
	void VN_master_stop();
	int VN_slave_start();
	void VN_slave_stop();
	void VN_enslaving();

	int VN_client_start();
	void VN_client_stop();

	int VN_server_start();
	void VN_server_stop();




	void VN_SocketStart(bool set_on);
	bool VN_IsSocketSetOn();

	void VN_ServSocketStart(bool set_on);
	bool VN_IsServSocketSetOn();

	int VN_IsSlave();
	//void VN_SetModus(bool set_modus);
	void VN_SetNetModus(int set_modus);

	void VN_SetClient(bool set_modus);
	void VN_SetServer(bool set_modus);

	void VN_SetHostname(char set_hostname[256]);
	void VN_SetPort(int set_portnumber);
	void VN_SetTimeOut(int set_timeout);
	//void VN_FillOut(float filldata[16]);

	void VN_SetServPort(int set_portnumber);
	void VN_SetServTimeOut(int set_timeout);


	// Virtual overrides
	CKERROR OnCKReset();
	CKERROR PreProcess();
	CKERROR OnCKInit();
	CKERROR OnCKPlay();
	CKERROR OnCKPause();
	CKERROR OnCKEnd();

	// Valid functions mask
	CKDWORD	GetValidFunctionsMask()	{ return CKMANAGER_FUNC_OnCKReset|
											 CKMANAGER_FUNC_PreProcess|
											 CKMANAGER_FUNC_OnCKInit|
											 CKMANAGER_FUNC_OnCKPlay|
											 CKMANAGER_FUNC_OnCKPause|
											 CKMANAGER_FUNC_OnCKEnd;}

	//Class vars..
	// Booleans to control manager
	bool socket_on; //do we want the socket to be started? 
	bool servsocket_on; //do we want the listening (server) socket to be started? 


	//bool slave;   //is the manager running as master or slave?
	//change - new var netmode 
	//	0 master (0 same as old client)
	//	1 slave 
	// 	2 socket mode
	//	if in socket mode must differentiate between client and server
	//	new var sockmode 
	// 		0 client
	// 		1 eywserver
	//bool client;   //is the manager running as client?

	int netmode;
	
	//int sockmode;
	//change - sockmode will not do good, client/server may be concurrent
	bool client;
	bool server;
	
	bool mst_on;  //is master on?
	bool slv_on;  //is slave on?
	bool clt_on;  //is client on?
	bool srv_on;  //is server on?

	//char to hold hostname/ipaddr for master to connect to.
	char host[256];
	//int to hold the portnumber.
	int port;
	//int to hold timeout value (s)
	int timeout;
	//int to hold the listening socket - server
	int srvport;
	//int to hold timeout value (s) - listening socket - server
	int srvtimeout;


	//master en slave structs
	sock_master_struct *mst;
	sock_slave_struct *slv;
	
	//for client
	sock_client_struct *clt;
	//for server
	sock_server_struct *srv;

	//the first float [0] contains status codes:
	// 0 = connection dead
	// 1 = connection alive
	// 2 = play
	// 3 = pause
	// 4 = reset (which should be followed by 1)
	float out[20];
	float *in;
	int *in_int;
	char *inCharP;
	char *inCharP_serv;
	char inChar[512];
	int status;

	//counts frames in order to give sync feedback
	int framecount;
	
	//output array for server
	CKDataArray* o_array;

};
