//#pragma comment( lib, "wsock32.lib" )
#pragma comment( lib, "ws2_32.lib" )
#include <string.h>
#include <stdio.h>


// include headers based on OS
#if defined WIN32
#include <winsock2.h>  // WinSock subsystem
#elif defined __linux__
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#endif


// redefine some types and constants based on OS
#if defined WIN32
typedef int socklen_t;  // Unix socket length
#elif defined __linux__
typedef int SOCKET;
#define INVALID_SOCKET -1  // WinSock invalid socket
#define SOCKET_ERROR   -1  // basic WinSock error
#define closesocket(s) close(s);  // Unix uses file descriptors, WinSock doesn't...
#endif

#include "CKAll.h"

struct sock_slave_struct
{
	SOCKET s;
	SOCKET t;
	int port;
	struct sockaddr_in addr;
	struct sockaddr_in r_addr;
	socklen_t slen;
	int buflen;
	void *buffer;
	WSADATA wsa_data;
};

struct sock_master_struct
{
	struct sockaddr_in addr;
	SOCKET s;
	struct hostent *h;
	int buflen;
	WSADATA wsa_data;
};


struct sock_client_struct
{
	struct sockaddr_in server;
	SOCKET s;
	int port;
	struct hostent *h;
	int buflen;
	void *buffer;
	char cbuffer[512];
	char *cbufferp;
	WSADATA wsa_data;
};

struct sock_server_struct
{	
	SOCKET s;
	SOCKET t;
	int port;
	struct sockaddr_in addr;
	struct sockaddr_in r_addr;
	socklen_t slen;
	//struct hostent *h;
	int buflen;
	void *buffer;
	char cbuffer[16388]; //128X128+4
	//char *cbufferp;
	WSADATA wsa_data;
};


void sock_slave_stop(sock_slave_struct *);
sock_slave_struct * sock_slave_start(int port,int timeout);
void *sock_slave_getdata(sock_slave_struct *slv,int o);

sock_master_struct * sock_master_start(int buflen,char *host,int port);
void sock_master_stop(sock_master_struct *mst);
int sock_master_senddata(void *data,sock_master_struct *mst);

sock_client_struct * sock_client_start(char *host,int port);
void sock_client_stop(sock_client_struct *clt);
int sock_client_senddata(char *instring,sock_client_struct *clt, CKContext *m_Context);
//void *sock_client_getdata(sock_client_struct *clt, int o, CKContext *m_Context);
char *sock_client_getdata(sock_client_struct *clt, int o, CKContext *m_Context);

sock_server_struct * sock_server_start(int port, int timeout, CKContext *m_Context);
void sock_server_stop(sock_server_struct *clt);
int sock_server_senddata(char *instring,sock_server_struct *clt, CKContext *m_Context);
char *sock_server_getdata(sock_server_struct *clt, int o, CKContext *m_Context);

